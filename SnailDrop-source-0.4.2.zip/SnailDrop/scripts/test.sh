#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d /private/tmp/cloudharbor-test.XXXXXX)"
SERVER_PID=""
cleanup() { if [ -n "$SERVER_PID" ]; then kill "$SERVER_PID" 2>/dev/null || true; fi; rm -rf "$TEMP"; }
trap cleanup EXIT
python3 "$ROOT/tests/http_fixture.py" "$TEMP/port" &
SERVER_PID=$!
for i in {1..100}; do [ -s "$TEMP/port" ] && break; sleep 0.05; done
PORT="$(cat "$TEMP/port")"
mkdir -p "$ROOT/.build/module-cache"
swiftc -swift-version 5 -O -module-cache-path "$ROOT/.build/module-cache" "$ROOT/macos/ParallelTransfer.swift" "$ROOT/macos/DownloadEngine.swift" "$ROOT/tests/Integration.swift" -o "$TEMP/tests"
"$TEMP/tests" "http://127.0.0.1:$PORT" "$TEMP/data"
