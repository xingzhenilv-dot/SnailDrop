#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP="$(mktemp -d /private/tmp/snaildrop-test.XXXXXX)"
trap 'rm -rf "$TEMP"' EXIT
mkdir -p "$ROOT/.build/module-cache"
swiftc -swift-version 5 -module-cache-path "$ROOT/.build/module-cache" "$ROOT/macos/SessionLog.swift" "$ROOT/macos/BaiduClient.swift" "$ROOT/tests/ClientAndLog.swift" -framework Cocoa -framework ApplicationServices -o "$TEMP/tests"
"$TEMP/tests" "$TEMP/data"
