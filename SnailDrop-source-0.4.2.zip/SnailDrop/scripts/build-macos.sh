#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP="$ROOT/dist/SnailDrop.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources/frontend" "$ROOT/.build/module-cache"
swiftc -swift-version 5 -O -module-cache-path "$ROOT/.build/module-cache" \
  "$ROOT/macos/SessionLog.swift" "$ROOT/macos/BaiduClient.swift" "$ROOT/macos/ParallelTransfer.swift" "$ROOT/macos/DownloadEngine.swift" "$ROOT/macos/App.swift" "$ROOT/macos/main.swift" \
  -framework Cocoa -framework WebKit -o "$APP/Contents/MacOS/SnailDrop"
cp "$ROOT"/frontend/* "$APP/Contents/Resources/frontend/"
cp "$ROOT/macos/Info.plist" "$APP/Contents/Info.plist"
if [ -f "$ROOT/macos/AppIcon.icns" ]; then cp "$ROOT/macos/AppIcon.icns" "$APP/Contents/Resources/"; fi
codesign --force --deep --sign - "$APP"
echo "Built: $APP"
