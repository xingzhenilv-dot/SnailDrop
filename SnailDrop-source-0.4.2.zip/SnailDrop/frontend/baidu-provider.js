// Executed only by CloudHarbor's native Download Selected button, on pan.baidu.com.
// Uses the user's existing first-party session; no external parsing service.
if (!['pan.baidu.com','yun.baidu.com'].includes(location.hostname) || location.protocol !== 'https:') {
  return {ok:false,message:'请先打开百度分享页面。'};
}
try {
  const unwrap = value => value && typeof value === 'object' && 'value' in value ? value.value : value;
  let raw = {};
  try { raw = window.locals?.dump?.() || {}; } catch (_) {}
  const info = Object.fromEntries(Object.entries(raw).map(([k,v])=>[k,unwrap(v)]));
  const old = window.yunData || {};
  const value = (...keys) => { for (const key of keys) { const v = info[key] ?? old[key]; if(v !== undefined && v !== null) return unwrap(v); } };
  let files = value('file_list','FILE_LIST','fileList');
  if (!Array.isArray(files)) files = files?.list || [];
  // Both modern and classic share pages are supported. Never download unselected
  // items when more than one item is visible.
  const checked = new Set();
  for (const row of document.querySelectorAll('.JS-list-view-item[data-file-key]')) {
    if (row.querySelector('.wp-checkbox--checked') || row.getAttribute('aria-selected')==='true') checked.add(row.getAttribute('data-file-key'));
  }
  let selected = files.filter(f=>checked.has(String(f.fs_id)));
  if (!selected.length) {
    try { selected = window.require('system-core:context/context.js').instanceForSystem.list.getSelected() || []; } catch (_) {}
  }
  if (typeof requestedFiles !== 'undefined') selected = requestedFiles;
  if (typeof requestedFiles === 'undefined' && !selected.length && files.length===1) selected = files;
  if (!selected.length) return {ok:false,message:'请先在百度页面勾选文件或文件夹，再点「用云泊下载所选」。'};
  const ids=selected.map(f=>String(f.fs_id));
  if (ids.some(id=>!/^\d+$/.test(id))) return {ok:false,message:'页面文件编号格式变化，无法安全请求下载。'};
  const uk = value('share_uk','SHARE_UK','uk');
  const shareid = value('shareid','share_id','SHARE_ID');
  if (!uk || !shareid) return {ok:false,message:'当前页面缺少分享信息。请从分享链接进入，等待文件列表出现后重试。'};
  const token = value('bdstoken','BDSTOKEN') || '';
  let sign = value('sign','SIGN'); let timestamp = value('timestamp','TIMESTAMP');
  const surl = location.pathname.match(/\/s\/([^/]+)/)?.[1] || new URLSearchParams(location.search).get('surl');
  const json = async (path, options={}) => {
    const response=await fetch(path,{...options,credentials:'same-origin',signal:AbortSignal.timeout(25000)});
    if(!response.ok)throw new Error('HTTP '+response.status);
    return response.json();
  };
  if ((!sign || !timestamp) && surl) {
    const query=new URLSearchParams({surl,fields:'sign,timestamp',channel:'chunlei',web:'1',app_id:'250528',clienttype:'0',bdstoken:String(token)});
    const data=await json('/share/tplconfig?'+query); const config=data.data || data;
    sign=config.sign; timestamp=config.timestamp;
  }
  if (!sign || !timestamp) return {ok:false,message:'未取得分享下载签名，请刷新分享页后重试。'};
  let sekey='';
  const cookie=document.cookie.split(';').map(x=>x.trim()).find(x=>x.startsWith('BDCLND='));
  if(cookie){try{sekey=decodeURIComponent(cookie.slice(7));}catch(_){sekey=cookie.slice(7);}}
  if(!sekey && surl){for(const key of [surl+'_bdclnd',surl.replace(/^1/,'')+'_bdclnd']){const stored=localStorage.getItem(key);if(stored){sekey=stored;break;}}}
  const query=new URLSearchParams({sign:String(sign),timestamp:String(timestamp),bdstoken:String(token),channel:'chunlei',clienttype:'0',web:'1',app_id:'250528'});
  const requestDownload = async type => {
    const form=new URLSearchParams({encrypt:'0',product:'share',uk:String(uk),primaryid:String(shareid),fid_list:'['+ids.join(',')+']',type,extra:JSON.stringify({sekey})});
    return json('/api/sharedownload?'+query,{method:'POST',body:form});
  };
  const extract = data => {
    if(data.errno!==0)return [];
    const list=Array.isArray(data.list)?data.list:[];
    const links=list.filter(f=>typeof f.dlink==='string').map(f=>({url:f.dlink,name:f.server_filename||selected.find(s=>String(s.fs_id)===String(f.fs_id))?.server_filename||'百度文件'}));
    if(typeof data.dlink==='string')links.push({url:data.dlink,name:selected.length===1?selected[0].server_filename+'.zip':'百度分享打包下载.zip'});
    return links.filter(f=>{try{return ['https:','http:'].includes(new URL(f.url).protocol);}catch(_){return false;}});
  };
  const isBatch=(typeof archive !== 'undefined' && archive) || selected.length>1 || selected.some(f=>Number(f.isdir)===1);
  let result=await requestDownload(isBatch?'batch':'nolimit');
  let links=extract(result);
  if(!links.length && !isBatch && (result.errno===0 || [112,113,118].includes(result.errno))) {
    // Some pages return a client-only encrypted list. Ask the same authorized
    // service for an ordinary ZIP stream, without launching the official client.
    result=await requestDownload('batch'); links=extract(result);
  }
  if(!links.length){
    const code=result.errno;
    return {ok:false,code:Number.isInteger(code)?code:0,message:code===-20?'百度要求验证码，请在官方页面完成验证后重试。':`百度暂未返回可用下载地址（错误码 ${code ?? '未知'}）。当前接口或账号不允许此下载；未保存或修改网盘文件。`};
  }
  return {ok:true,links};
} catch(error) {
  return {ok:false,message:'请求百度下载接口失败：'+(error.name==='TimeoutError'?'请求超时':error.message)};
}
