'use strict';
const $ = id => document.getElementById(id);
let state = {tasks:[],folder:'',concurrency:3};
const states = {refreshing:'正在刷新下载授权',queued:'等待中',running:'正在下载',pausing:'正在保存断点',paused:'已暂停',completed:'已完成',failed:'下载失败'};
function send(action, data={}) {
  if(window.webkit?.messageHandlers?.cloudharbor) window.webkit.messageHandlers.cloudharbor.postMessage({action,...data});
  else showToast('请在 Mac 应用内使用下载功能。');
}
function bytes(n){if(!n)return '0 B';const i=Math.min(3,Math.floor(Math.log(n)/Math.log(1024)));return (n/1024**i).toFixed(i?1:0)+' '+['B','KB','MB','GB'][i];}
function element(tag,text,className){const el=document.createElement(tag);if(text!==undefined)el.textContent=text;if(className)el.className=className;return el;}
function button(text,fn){const b=element('button',text);b.addEventListener('click',fn);return b;}
window.receiveNativeState = next => {
  state=next; $('folder').textContent=next.folder; $('concurrency').value=String(next.concurrency); $('connections').value=String(next.connections||4);
  const focused=document.activeElement;
  const focusKey=focused?.dataset?.key;
  const list=$('tasks'); list.replaceChildren();
  if(!next.tasks.length)list.append(element('div','暂无下载任务','empty'));
  for(const t of next.tasks){
    const row=element('div',undefined,'task');const head=element('div',undefined,'task-head');head.append(element('div',t.name,'task-name'));
    const controls=element('div',undefined,'task-buttons');
    const addControl=(label,action)=>{const b=button(label,()=>send(action,{id:t.id}));b.dataset.key=t.id+action;controls.append(b);};
    if(['running','queued','refreshing'].includes(t.state))addControl('暂停','pause');
    if(['paused','failed'].includes(t.state))addControl(t.state==='failed'?'重试':'继续','resume');
    if(t.state==='completed')addControl('在 Finder 显示','reveal');
    const remove=button('移除',()=>{if(confirm('从队列移除此任务？已完成的文件不会删除，未完成的断点将被清除。'))send('remove',{id:t.id});});remove.dataset.key=t.id+'remove';controls.append(remove);
    head.append(controls);row.append(head);
    row.append(element('div',`${states[t.state]||t.state} · ${t.source} · ${bytes(t.received)} / ${t.total?bytes(t.total):'未知大小'}${t.state==='running'?' · '+bytes(t.speed)+'/s':''}`,'task-meta'));
    const p=element('progress');p.max=t.total||1;if(t.total)p.value=t.received;else if(t.state!=='running')p.value=0;p.setAttribute('aria-label',t.name+' 下载进度');row.append(p);
    if(t.error)row.append(element('p',t.error,'task-error'));
    list.append(row);
  }
  if(focusKey){const target=Array.from(list.querySelectorAll('button')).find(b=>b.dataset.key===focusKey);target?.focus({preventScroll:true});}
  $('summary').textContent=`${next.tasks.filter(t=>t.state==='running').length} 个正在下载 · 总速度 ${bytes(next.tasks.reduce((n,t)=>n+t.speed,0))}/s`;
};
let toastTimer;
window.showToast = text => {clearTimeout(toastTimer);$('toast').textContent=text;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,6500);};
window.pasteLinks = text => {$('links').value=text;$('links').focus();};
$('baidu').onclick=()=>$('add').click();$('paste').onclick=()=>send('paste');
$('add').onclick=()=>{
  const text=$('links').value;
  const urls=[...new Set((text.match(/https?:\/\/[^\s<>"，。；）]+/g)||[]).map(s=>s.replace(/[),;]+$/,'')))];
  if(!urls.length){showToast('请输入有效的 HTTP / HTTPS 链接。');return;}
  const direct=[];let baiduOpened=false;
  for(const raw of urls){
    let u;try{u=new URL(raw);}catch{continue;}
    if(['pan.baidu.com','yun.baidu.com'].includes(u.hostname)){
      if(baiduOpened){showToast('一次打开一个百度分享页，其余分享请单独添加。');continue;}
      const code=text.match(/(?:提取码|密码)\s*[:：]?\s*([a-zA-Z0-9]{4})/);
      if(code&&!u.searchParams.has('pwd'))u.searchParams.set('pwd',code[1]);
      send('baidu',{url:u.href});baiduOpened=true;
    }else direct.push(u.href);
  }
  if(direct.length&&confirm(`确认添加 ${direct.length} 个直链下载任务？`))send('add',{urls:direct});
};
$('pauseAll').onclick=()=>send('pauseAll');$('resumeAll').onclick=()=>send('resumeAll');$('clear').onclick=()=>send('clearCompleted');
$('chooseFolder').onclick=()=>send('chooseFolder');$('openFolder').onclick=()=>send('folder');
$('connections').onchange=e=>send('connections',{value:Number(e.target.value)});
$('concurrency').onchange=e=>send('concurrency',{value:Number(e.target.value)});
$('logout').onclick=()=>{if(confirm('清除蜗牛速递内的百度网页登录信息？下次使用需要重新登录。'))send('logout');};
send('ready');

let share = {status:'idle',session:0,files:[]};
let selection=new Set();
function updateSelection(){
  $('shareConfirm').disabled=selection.size===0||share.status!=='ready';
  $('selectionCount').textContent=selection.size?`已选 ${selection.size} 项`:'未选择文件';
}
window.receiveShareState=next=>{
  if(next.session!==share.session||next.directory!==share.directory||share.status==='resolving')selection.clear();
  share=next;
  $('sharePanel').hidden=false;
  $('shareTitle').textContent=next.title||'分享文件';
  $('shareStatus').textContent=next.message||(next.status==='ready'?'勾选需要的文件，然后确认下载。':'正在读取…');
  $('shareControls').hidden=!['ready','resolving'].includes(next.status);
  $('shareCancel').disabled=next.status==='resolving';
  $('sharePath').textContent=next.directory||'分享根目录';
  $('shareRoot').textContent=next.personal?'回到所选文件':'回到分享根目录';
  $('shareRoot').disabled=!next.directory||next.status!=='ready';
  $('selectAll').disabled=next.status!=='ready';
  $('downloadMode').disabled=next.personal||next.status!=='ready';
  $('downloadMode').options[0].textContent=next.personal?'原文件（保留文件夹结构）':'原文件（文件夹打包 ZIP）';
  if(next.personal)$('downloadMode').value='original';
  const list=$('shareFiles');list.replaceChildren();
  for(const f of next.files||[]){
    const row=element('div',undefined,'share-row');
    const label=element('label');const box=element('input');box.type='checkbox';box.checked=selection.has(f.id);box.disabled=next.status!=='ready';box.setAttribute('aria-label','选择 '+f.name);
    box.onchange=()=>{if(box.checked)selection.add(f.id);else selection.delete(f.id);updateSelection();};
    label.append(box,element('span',f.name));row.append(label,element('span',f.directory?(next.personal?'文件夹（逐个文件下载）':'文件夹（下载为 ZIP）'):bytes(f.size),'task-meta'));
    if(f.directory){const enter=button('打开文件夹',()=>{selection.clear();send('shareBrowse',{session:share.session,fileId:f.id});});enter.disabled=next.status!=='ready';row.append(enter);}
    list.append(row);
  }
  if(next.status==='ready'&&!next.files?.length)list.append(element('p','这个文件夹没有可显示的文件。'));
  updateSelection();
};
$('shareCancel').onclick=()=>{selection.clear();send('shareCancel');};
$('shareRoot').onclick=()=>{selection.clear();send('shareBrowse',{session:share.session,fileId:''});};
$('selectAll').onclick=()=>{if(selection.size===share.files.length)selection.clear();else selection=new Set(share.files.map(f=>f.id));receiveShareState(share);};
$('shareConfirm').onclick=()=>{if(share.status!=='ready'||!selection.size)return;if(selection.size>100){showToast('一次最多选择 100 项，可直接选择上层文件夹打包。');return;}const ids=[...selection];share.status='resolving';updateSelection();send('shareConfirm',{session:share.session,ids,archive:$('downloadMode').value==='zip'});};

window.receiveClientState=next=>{
 const c=next.client||{};
 $('clientStatus').textContent=c.running?`百度客户端正在运行 · ${c.version} · ${c.accessible?'已具备读取界面权限':'尚未授予读取界面权限'}`:(c.installed?'百度客户端已安装，尚未运行。':'没有检测到已安装的百度客户端。');
 $('clientMessage').textContent=next.message||'';
 const list=$('clientItems');list.replaceChildren();
 for(const item of next.items||[]){const row=element('div',undefined,'share-row');row.append(element('strong',item.name),element('span',item.detail,'task-meta'));list.append(row);}
 $('clientConfirm').disabled=next.status!=='ready'||!c.running;
 $('clientRead').disabled=!c.running||['reading','submitting'].includes(next.status);
 $('clientAccess').disabled=c.accessible===true;
 $('clientLaunch').disabled=!c.installed;
};
window.receiveDiagnostics=text=>{$('report').textContent=text;};
$('clientLaunch').onclick=()=>send('clientLaunch');$('clientRefresh').onclick=()=>send('clientRefresh');
$('clientAccess').onclick=()=>send('clientAccess');$('clientRead').onclick=()=>send('clientRead');
$('clientConfirm').onclick=()=>{$('clientConfirm').disabled=true;send('clientConfirm');};
$('reportCopy').onclick=()=>send('reportCopy');$('reportRefresh').onclick=()=>send('reportRefresh');
send('clientRefresh');send('reportRefresh');
