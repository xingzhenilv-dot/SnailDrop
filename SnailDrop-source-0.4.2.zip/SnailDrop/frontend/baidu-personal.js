// Authorized first-party web session. File bytes are downloaded by SnailDrop,
// never by the official client's transfer queue. No account state is exported.
if(location.protocol!=='https:'||!['pan.baidu.com','yun.baidu.com'].includes(location.hostname))return {status:'error',message:'需要在蜗牛中完成百度下载授权。'};
try{
 const request=async(path)=>{const r=await fetch(path+(path.includes('?')?'&':'?')+'_='+Date.now(),{cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(20000)});if(!r.ok)throw Object.assign(Error('HTTP '+r.status),{code:r.status});const d=await r.json();if(d.errno!==0)throw Object.assign(Error('百度接口错误 '+d.errno),{code:Number(d.errno)||0});return d;};
 const validPath=p=>typeof p==='string'&&p.startsWith('/')&&!p.split('/').some(s=>s==='.'||s==='..')&&!p.includes('\u0000');
 const metadata=async(target,dlink)=>{
  const info=[];
  const endpoint=items=>'/api/filemetas?'+new URLSearchParams({target:JSON.stringify(items),dlink:dlink?'1':'0',web:'1',clienttype:'0'});
  let batch=[];
  const flush=async()=>{
   if(!batch.length)return;
   const d=await request(endpoint(batch));
   if(!Array.isArray(d.info))throw Error('百度没有返回可识别的文件信息。');
   info.push(...d.info);batch=[];
  };
  for(const path of target){
   if(endpoint([path]).length>3800)throw Error('单个文件路径过长，请缩短网盘中的目录或文件名后重试。');
   if(batch.length&&endpoint([...batch,path]).length>3800)await flush();
   batch.push(path);
  }
  await flush();return info;
 };
 const list=async(dir)=>{
  if(!validPath(dir))throw Error('文件夹路径无效。');const files=[];
  for(let page=1;page<=100;page++){
   const q=new URLSearchParams({dir,page:String(page),num:'100',order:'name',desc:'0',showempty:'0',web:'1',clienttype:'0'});
   const d=await request('/api/list?'+q);if(!Array.isArray(d.list))throw Error('百度没有返回文件夹内容。');files.push(...d.list);
   if(d.has_more===0||d.has_more===false||d.list.length<100)return files;
  }
  throw Error('单个目录超过一万项，请分目录读取。');
 };
 const webLinks=async(files)=>{
  const fields=encodeURIComponent(JSON.stringify(['sign1','sign3','timestamp','bdstoken']));
  const response=await request('/api/gettemplatevariable?fields='+fields+'&web=1&clienttype=0');
  const vars=response.result||response.data||response;
  if(typeof vars.sign1!=='string'||!vars.sign1||typeof vars.sign3!=='string'||!vars.sign3||!vars.timestamp)throw Error('百度未向当前网页会话提供下载签名，需要进一步接入正式下载授权。');
  const state=Array.from({length:256},(_,i)=>i);let j=0;
  for(let i=0;i<256;i++){j=(j+state[i]+vars.sign3.charCodeAt(i%vars.sign3.length))&255;[state[i],state[j]]=[state[j],state[i]];}
  let a=0,b=0,output='';
  for(const char of vars.sign1){a=(a+1)&255;b=(b+state[a])&255;[state[a],state[b]]=[state[b],state[a]];output+=String.fromCharCode(char.charCodeAt(0)^state[(state[a]+state[b])&255]);}
  const ids=files.map(f=>String(f.fs_id));if(ids.some(id=>!/^\d+$/.test(id)))throw Error('百度文件编号格式异常。');
  const q=new URLSearchParams({fidlist:'['+ids.join(',')+']',type:'dlink',sign:btoa(output),timestamp:String(vars.timestamp),bdstoken:String(vars.bdstoken||''),web:'1',clienttype:'0',channel:'chunlei',app_id:'250528'});
  const d=await request('/api/download?'+q);
  if(!Array.isArray(d.dlink))throw Error('百度没有返回网页会话可用的下载地址，未创建下载任务。');
  const expired=raw=>{
   try{const u=new URL(raw);const stamp=Number(u.searchParams.get('dstime'));const expiry=u.searchParams.get('expires')?.match(/^(\d+)([smhd]?)$/);if(!stamp||!expiry)return false;const duration=Number(expiry[1])*({s:1,m:60,h:3600,d:86400}[expiry[2]]||1);return stamp+duration<Math.floor(Date.now()/1000)-300;}catch{return false;}
  };
  let resolved=files.map(f=>({...f,dlink:d.dlink.find(link=>String(link.fs_id)===String(f.fs_id))?.dlink}));
  if(resolved.some(f=>expired(f.dlink))){
   // Request an alternate authorized metadata link; never edit signed URL fields.
   const alternate=await metadata(files.map(f=>f.path),true);
   resolved=resolved.map(f=>expired(f.dlink)?({...f,dlink:alternate.find(a=>String(a.fs_id)===String(f.fs_id))?.dlink}):f);
   if(resolved.some(f=>expired(f.dlink)))throw Error('百度返回的下载地址已过期，两个授权接口均未提供有效链接。请稍后重试或重新登录。');
  }
  return resolved;
 };
 const normalized=files=>files.map(f=>({id:String(f.fs_id),name:String(f.server_filename||f.path?.split('/').pop()||'未命名'),size:Number(f.size)||0,directory:Number(f.isdir)===1,path:String(f.path||'')}));
 if(operation==='inspect'){
  if(!Array.isArray(paths)||!paths.length||paths.length>100||!paths.every(validPath))throw Error('未取得有效的客户端文件路径。');
  const files=await metadata(paths,false);
  if(files.length!==new Set(paths).size)throw Error('所选文件与当前授权账号不匹配，请确认两端登录的是同一百度账号。');
  return {status:'ready',title:'客户端所选 · 蜗牛下载',files:normalized(files)};
 }
 if(operation==='list')return {status:'ready',title:'客户端所选 · 蜗牛下载',files:normalized(await list(directory))};
 if(operation==='download'){
  if(!Array.isArray(paths)||!paths.length||!paths.every(validPath))throw Error('所选文件路径无效。');
  const pending=await metadata(paths,false);const files=[];const seen=new Set();
  while(pending.length){
   const f=pending.shift();if(!validPath(f.path))throw Error('百度返回的路径格式异常。');
   if(seen.has(f.path))continue;seen.add(f.path);
   if(seen.size>1000)throw Error('本次文件夹超过一千项，请拆分选择后下载。');
   if(Number(f.isdir)===1)pending.push(...await list(f.path));else files.push(f);
  }
  if(!files.length)throw Error('所选文件夹为空。');
  const toLink=(f,url)=>{
   const selectedRoot=paths.find(p=>f.path===p||f.path.startsWith(p.replace(/\/$/,'')+'/'));
   if(!selectedRoot)throw Error('返回的文件不在所选目录内。');
   const rootParent=selectedRoot.substring(0,selectedRoot.lastIndexOf('/')+1);
   const parts=f.path.slice(rootParent.length).split('/');const name=parts.pop();
   return {url,name,baiduPath:f.path,relativeDirectory:parts.join('/')};
  };
  if(typeof preferPCS==='undefined'||preferPCS){
   return {ok:true,links:files.map(f=>{
    const url=new URL('https://pcs.baidu.com/rest/2.0/pcs/file');
    url.search=new URLSearchParams({method:'download',app_id:'250528',path:f.path}).toString();
    return toLink(f,url.href);
   })};
  }
  const links=[];
  for(let start=0;start<files.length;start+=50){
   const batch=await webLinks(files.slice(start,start+50));
   for(const f of batch){
    if(typeof f.dlink!=='string'||!/^https?:\/\//i.test(f.dlink))throw Error('百度未提供可用下载地址，文件尚未进入队列。需要重新授权或进一步适配此接口。');
    links.push(toLink(f,f.dlink));
   }
   if(batch.length!==Math.min(50,files.length-start))throw Error('部分文件没有返回下载地址，未创建下载任务。');
  }
  return {ok:true,links};
 }
 return {status:'error',message:'未知请求。'};
}catch(error){return {ok:false,status:'error',code:error.code||0,message:'获取百度文件信息失败：'+(error.name==='TimeoutError'?'请求超时':error.message)};}
