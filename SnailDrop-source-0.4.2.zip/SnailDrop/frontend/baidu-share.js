// Read-only share browser. Tokens and cookies remain in this first-party WebView.
if(location.protocol!=='https:' || !['pan.baidu.com','yun.baidu.com'].includes(location.hostname))return {status:'login'};
const unwrap=v=>v&&typeof v==='object'&&'value' in v?v.value:v;
let raw={};try{raw=window.locals?.dump?.()||{};}catch(_){}
const info=Object.fromEntries(Object.entries(raw).map(([k,v])=>[k,unwrap(v)]));
const old=window.yunData||{};
const get=(...keys)=>{for(const k of keys){const v=info[k]??old[k];if(v!=null)return unwrap(v);}};
const json=async path=>{const r=await fetch(path,{credentials:'same-origin',signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('HTTP '+r.status);return r.json();};
try{
  if(operation==='auth'){
    const a=await json('/api/gettemplatevariable?fields='+encodeURIComponent(JSON.stringify(['is_login','bdstoken']))+'&clienttype=0&web=1');
    const result=a.result||a.data||a;
    const login=result.is_login??get('is_login','loginstate','IS_LOGIN');
    return {status:login===true||Number(login)===1?'authenticated':'login'};
  }
  const uk=get('share_uk','SHARE_UK','uk');const shareid=get('shareid','share_id','SHARE_ID');
  let files=get('file_list','FILE_LIST','fileList');if(!Array.isArray(files))files=files?.list;
  if(!uk||!shareid||!Array.isArray(files)){
    const text=document.body?.innerText||'';
    if(/提取码/.test(text)&&document.querySelector('input'))return {status:'verification',message:'请在百度窗口输入提取码或完成验证。'};
    if(/失效|不存在|已取消|已过期/.test(text))return {status:'error',message:'分享已失效或不可访问，请检查链接。'};
    return {status:'loading'};
  }
  if(operation==='list'&&directory){
    files=[];let done=false;
    for(let page=1;page<=100;page++){
      const q=new URLSearchParams({uk:String(uk),shareid:String(shareid),dir:directory,page:String(page),num:'100',order:'name',desc:'0',showempty:'0',web:'1',clienttype:'0'});
      const data=await json('/share/list?'+q);
      if(data.errno!==0||!Array.isArray(data.list))return {status:'error',message:'无法读取文件夹（百度错误码 '+data.errno+'）。请重新解析或完成验证。'};
      files.push(...data.list);
      if(data.has_more===0||data.has_more===false||data.list.length<100){done=true;break;}
    }
    if(!done)return {status:'error',message:'该目录超过一万项，请分目录处理。'};
  }
  return {status:'ready',files:files.map(f=>({id:String(f.fs_id),name:String(f.server_filename||'未命名'),size:Number(f.size)||0,directory:Number(f.isdir)===1,path:String(f.path||'')})),title:document.title.split('_')[0]||'百度分享'};
}catch(error){return {status:'error',message:'读取分享失败：'+(error.name==='TimeoutError'?'网络超时，请重试。':error.message)};}
