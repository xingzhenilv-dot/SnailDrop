import Foundation

// One transfer owns its session and a serial delegate queue. Every byte is checked
// against the negotiated range before it is written. No account-specific logic.
final class ParallelTransfer: NSObject, URLSessionDataDelegate {
    struct Segment: Codable { var start: Int64; var end: Int64; var written: Int64 = 0 }
    struct Checkpoint: Codable { var url: String; var size: Int64; var validator: String; var segments: [Segment] }
    let url: URL
    let directory: URL
    let headers: [String: String]
    let connections: Int
    var progress: ((Int64, Int64) -> Void)?
    var completed: ((Result<URL, Error>) -> Void)?
    var fallback: (() -> Void)?
    var paused: (() -> Void)?
    private var checkpoint: Checkpoint?
    private var probe: Int?
    private var tasks: [Int: Int] = [:]
    private var handles: [Int: FileHandle] = [:]
    private var retries: [Int: Int] = [:]
    private var requests: [Int: (Int64, Int64)] = [:]
    private var accepted = Set<Int>()
    private var stopped = false
    private var lastSave = Date.distantPast
    private lazy var session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 30
        c.timeoutIntervalForResource = 86400
        c.httpMaximumConnectionsPerHost = max(1, connections)
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: c, delegate: self, delegateQueue: .main)
    }()
    init(url: URL, directory: URL, headers: [String: String], connections: Int = 4) {
        self.url = url; self.directory = directory; self.headers = headers; self.connections = max(1, min(8, connections))
    }
    private func problem(_ text: String, code: Int = 1) -> NSError { NSError(domain: "CloudHarbor", code: code, userInfo: [NSLocalizedDescriptionKey: text]) }
    private func request() -> URLRequest {
        var r = URLRequest(url: url)
        for (k,v) in headers { r.setValue(v, forHTTPHeaderField: k) }
        r.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        return r
    }
    func start() {
        var r = request(); r.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        let t = session.dataTask(with: r); probe = t.taskIdentifier; t.resume()
    }
    private func segmentURL(_ index: Int) -> URL { directory.appendingPathComponent("\(index).part") }
    private func save() throws {
        guard let checkpoint else { return }
        for handle in handles.values { try handle.synchronize() }
        let path = directory.appendingPathComponent("checkpoint.json")
        try JSONEncoder().encode(checkpoint).write(to: path, options: .atomic)
        try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: path.path)
        lastSave = Date()
    }
    private func prepare(size: Int64, validator: String) throws {
        let file = directory.appendingPathComponent("checkpoint.json")
        if let data = try? Data(contentsOf: file), var old = try? JSONDecoder().decode(Checkpoint.self, from: data),
           old.url == url.absoluteString, old.size == size, !validator.isEmpty, old.validator == validator,
           !old.segments.isEmpty, old.segments.first?.start == 0, old.segments.last?.end == size - 1 {
            var expected: Int64 = 0
            var valid = true
            for i in old.segments.indices {
                let s = old.segments[i]
                if s.start != expected || s.end < s.start || s.written < 0 || s.written > s.end - s.start + 1 { valid = false; break }
                expected = s.end + 1
                let path = segmentURL(i)
                let diskSize = (try? FileManager.default.attributesOfItem(atPath: path.path)[.size] as? NSNumber)?.int64Value ?? -1
                if diskSize < s.written { valid = false; break }
                // Bytes not covered by a durable checkpoint may be from an interrupted write.
                let handle = try FileHandle(forWritingTo: path); try handle.truncate(atOffset: UInt64(s.written)); try handle.close()
                old.segments[i].written = s.written
            }
            if valid { checkpoint = old; return }
        }
        if FileManager.default.fileExists(atPath: directory.path) { try FileManager.default.removeItem(at: directory) }
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        let count = min(connections, max(1, Int(size / (1024 * 1024))))
        let length = (size + Int64(count) - 1) / Int64(count)
        var segments: [Segment] = []
        for i in 0..<count {
            let start = Int64(i) * length
            if start >= size { break }
            segments.append(Segment(start: start, end: min(size - 1, start + length - 1)))
            guard FileManager.default.createFile(atPath: segmentURL(i).path, contents: nil, attributes: [.posixPermissions: 0o600]) else { throw problem("无法创建下载分片") }
        }
        checkpoint = Checkpoint(url: url.absoluteString, size: size, validator: validator, segments: segments)
        try save()
    }
    private func launch(_ index: Int) throws {
        guard !stopped, let state = checkpoint else { return }
        let s = state.segments[index]
        if s.written == s.end - s.start + 1 { return }
        var r = request(); let start = s.start + s.written
        r.setValue("bytes=\(start)-\(s.end)", forHTTPHeaderField: "Range")
        if !state.validator.isEmpty { r.setValue(Self.httpValidator(state.validator), forHTTPHeaderField: "If-Range") }
        let h = try FileHandle(forWritingTo: segmentURL(index)); try h.seekToEnd()
        let t = session.dataTask(with: r)
        handles[t.taskIdentifier] = h; tasks[t.taskIdentifier] = index; requests[t.taskIdentifier] = (start, s.end)
        t.resume()
    }
    private func fail(_ error: Error) {
        guard !stopped else { return }
        stopped = true; try? save(); closeHandles(); session.invalidateAndCancel(); completed?(.failure(error))
    }
    private func closeHandles() { for h in handles.values { try? h.close() }; handles.removeAll() }
    func pause() {
        guard !stopped else { return }
        do { try save() } catch { fail(error); return }
        stopped = true; closeHandles(); session.invalidateAndCancel(); paused?()
    }
    func cancel() { stopped = true; closeHandles(); session.invalidateAndCancel() }
    private func report() { if let c = checkpoint { progress?(c.segments.reduce(0) { $0 + $1.written }, c.size) } }
    private func finishIfReady() throws {
        guard !stopped, let c = checkpoint, c.segments.allSatisfy({ $0.written == $0.end - $0.start + 1 }) else { return }
        closeHandles(); try save()
        let output = directory.appendingPathComponent("assembled.part")
        if FileManager.default.fileExists(atPath: output.path) { try FileManager.default.removeItem(at: output) }
        guard FileManager.default.createFile(atPath: output.path, contents: nil, attributes: [.posixPermissions: 0o600]) else { throw problem("无法合并下载分片") }
        let writer = try FileHandle(forWritingTo: output)
        defer { try? writer.close() }
        for i in c.segments.indices {
            let reader = try FileHandle(forReadingFrom: segmentURL(i)); defer { try? reader.close() }
            while let data = try reader.read(upToCount: 1024 * 1024), !data.isEmpty { try writer.write(contentsOf: data) }
        }
        try writer.synchronize()
        let actual = (try FileManager.default.attributesOfItem(atPath: output.path)[.size] as? NSNumber)?.int64Value
        guard actual == c.size else { throw problem("下载长度校验失败，请重试") }
        stopped = true; session.finishTasksAndInvalidate(); completed?(.success(output))
    }
    static func httpValidator(_ value: String) -> String {
        // PCS exposes bare MD5 ETags; If-Range requires a quoted entity tag.
        if value.count == 32 && value.allSatisfy({ $0.isHexDigit }) { return "\"" + value + "\"" }
        return value
    }
    static func parseRange(_ value: String) -> (Int64, Int64, Int64)? {
        // Baidu PCS omits the "bytes " unit. Keep bounds checks identical.
        let normalized = value.trimmingCharacters(in: .whitespacesAndNewlines)
        let range = normalized.hasPrefix("bytes ") ? String(normalized.dropFirst(6)) : normalized
        let components = range.split(separator: "/")
        guard components.count == 2, let size = Int64(components[1]), size > 0 else { return nil }
        let ends = components[0].split(separator: "-")
        guard ends.count == 2, let a = Int64(ends[0]), let b = Int64(ends[1]), a >= 0, b >= a, b < size else { return nil }
        return (a, b, size)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse, completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard !stopped, let r = response as? HTTPURLResponse else { completionHandler(.cancel); return }
        if dataTask.taskIdentifier == probe {
            probe = nil; completionHandler(.cancel)
            // A server may forbid Range while still allowing an ordinary GET.
            // The full-download path independently checks its HTTP response.
            if [200, 403, 416].contains(r.statusCode) {
                stopped = true; session.invalidateAndCancel(); fallback?(); return
            }
            guard r.statusCode == 206, let (a,b,size) = Self.parseRange(r.value(forHTTPHeaderField: "Content-Range") ?? ""), a == 0, b == 0 else {
                fail(problem("探测下载失败（HTTP \(r.statusCode)）。链接可能已过期，请重新从网盘获取。")); return
            }
            if r.mimeType == "text/html" { fail(problem("下载地址返回了网页，请重新获取文件链接。")); return }
            let etag = r.value(forHTTPHeaderField: "ETag") ?? ""
            let validator = !etag.isEmpty && !etag.hasPrefix("W/") ? etag : (r.value(forHTTPHeaderField: "Last-Modified") ?? "")
            // A stable validator is necessary to avoid mixing revisions across connections.
            if validator.isEmpty { stopped = true; session.invalidateAndCancel(); fallback?(); return }
            do {
                try prepare(size: size, validator: validator); report()
                for i in checkpoint!.segments.indices { try launch(i) }
                try finishIfReady()
            } catch { fail(error) }
            return
        }
        guard let (start,end) = requests[dataTask.taskIdentifier], let c = checkpoint else { completionHandler(.cancel); return }
        // Some origins accept the one-byte probe but ignore Range/If-Range on
        // real requests. Discard every segment and restart as a full download.
        if r.statusCode == 200 {
            completionHandler(.cancel); stopped = true; closeHandles()
            session.invalidateAndCancel()
            try? FileManager.default.removeItem(at: directory)
            fallback?(); return
        }
        guard r.statusCode == 206, let (a,b,size) = Self.parseRange(r.value(forHTTPHeaderField: "Content-Range") ?? ""), a == start, b == end, size == c.size,
              ["", "identity", "none"].contains((r.value(forHTTPHeaderField: "Content-Encoding") ?? "").lowercased()) else {
            completionHandler(.cancel)
            let actual = Self.parseRange(r.value(forHTTPHeaderField: "Content-Range") ?? "")
            fail(problem("分片响应不符合请求（HTTP \(r.statusCode)，预期 \(start)-\(end)，实际 \(actual.map { "\($0.0)-\($0.1)/\($0.2)" } ?? "无有效范围")）。已停止以防文件损坏。")); return
        }
        let etag = r.value(forHTTPHeaderField: "ETag") ?? ""
        let validator = !etag.isEmpty && !etag.hasPrefix("W/") ? etag : (r.value(forHTTPHeaderField: "Last-Modified") ?? "")
        guard validator.isEmpty || validator == c.validator else { completionHandler(.cancel); fail(problem("远端文件已变化，请重新添加任务。")); return }
        accepted.insert(dataTask.taskIdentifier); completionHandler(.allow)
    }
    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard !stopped, accepted.contains(dataTask.taskIdentifier), let i = tasks[dataTask.taskIdentifier], let c = checkpoint, let h = handles[dataTask.taskIdentifier] else { return }
        guard c.segments[i].written + Int64(data.count) <= c.segments[i].end - c.segments[i].start + 1 else { fail(problem("服务器返回的数据超出分片大小")); return }
        do {
            try h.write(contentsOf: data); checkpoint!.segments[i].written += Int64(data.count)
            if Date().timeIntervalSince(lastSave) > 1 { try save() }
            report()
        } catch { fail(error) }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard !stopped else { return }
        if task.taskIdentifier == probe {
            probe = nil; fail(error ?? problem("无法探测下载地址")); return
        }
        guard let i = tasks.removeValue(forKey: task.taskIdentifier) else { return }
        try? handles.removeValue(forKey: task.taskIdentifier)?.close(); accepted.remove(task.taskIdentifier); requests.removeValue(forKey: task.taskIdentifier)
        do {
            if let c = checkpoint, c.segments[i].written < c.segments[i].end - c.segments[i].start + 1 {
                let attempt = (retries[i] ?? 0) + 1; retries[i] = attempt
                guard attempt <= 3 else { fail(error ?? problem("下载分片不完整，重试三次仍未完成")); return }
                try save()
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(attempt)) { [weak self] in
                    guard let self, !self.stopped else { return }
                    do { try self.launch(i) } catch { self.fail(error) }
                }
            } else { try finishIfReady() }
        } catch { fail(error) }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        var next = request
        // Foundation may rebuild the redirected request. The CDN requires the
        // same transfer headers as the initial authorized request.
        for field in ["User-Agent", "Range", "If-Range", "Accept-Encoding"] {
            if let value = task.originalRequest?.value(forHTTPHeaderField:field) { next.setValue(value,forHTTPHeaderField:field) }
        }
        if response.url?.host?.lowercased() != request.url?.host?.lowercased() {
            next.setValue(nil, forHTTPHeaderField: "Cookie")
            next.setValue(nil, forHTTPHeaderField: "Authorization")
        }
        if response.url?.scheme == "https", request.url?.scheme != "https" {
            completionHandler(nil); return
        }
        completionHandler(next)
    }

}
