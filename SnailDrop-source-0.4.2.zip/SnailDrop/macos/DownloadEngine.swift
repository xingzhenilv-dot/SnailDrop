import Foundation

struct Transfer: Codable {
    var id = UUID().uuidString
    var url: String
    var name: String
    var state = "queued"
    var received: Int64 = 0
    var total: Int64 = 0
    var speed: Double = 0
    var path = ""
    var error = ""
    var created = Date().timeIntervalSince1970
    var baiduPath: String?
    var source = "直链"
}

final class DownloadEngine: NSObject, URLSessionDownloadDelegate {
    var items: [Transfer] = []
    var onChange: (() -> Void)?
    var onDiagnostic: ((String, Int) -> Void)?
    var onRefresh: ((String, @escaping (Result<(String, [String:String]), Error>) -> Void) -> Void)?
    var connections = 4
    private var refreshing: [String: UUID] = [:]
    private var refreshed = Set<String>()
    let storage: URL
    var folder: URL
    var limit = 3
    private var parallel: [String: ParallelTransfer] = [:]
    private var active: [String: URLSessionDownloadTask] = [:]
    private var identities: [Int: String] = [:]
    private var samples: [String: (Date, Int64)] = [:]
    private var headers: [String: [String: String]] = [:]
    private lazy var session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 45
        c.timeoutIntervalForResource = 86400 * 7
        c.httpMaximumConnectionsPerHost = 4
        c.requestCachePolicy = .reloadIgnoringLocalCacheData
        return URLSession(configuration: c, delegate: self, delegateQueue: .main)
    }()
    init(storage: URL, folder: URL) {
        self.storage = storage; self.folder = folder
        super.init()
        try? FileManager.default.createDirectory(at: storage, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        if let d = try? Data(contentsOf: storage.appendingPathComponent("tasks.json")), let saved = try? JSONDecoder().decode([Transfer].self, from: d) {
            items = saved.map { var t = $0; if ["running", "queued", "pausing", "refreshing"].contains(t.state) { t.state = "paused" }; t.speed = 0; return t }
        }
    }
    func notify(persist: Bool = true) {
        if persist { save() }
        onChange?()
    }
    func save() {
        do {
            let dest = storage.appendingPathComponent("tasks.json")
            try JSONEncoder().encode(items).write(to: dest, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: dest.path)
        } catch { NSLog("CloudHarbor: unable to save tasks: %@", error.localizedDescription) }
    }
    static func validURL(_ text: String) -> URL? {
        guard let u = URL(string: text), ["http", "https"].contains(u.scheme?.lowercased() ?? ""), u.host != nil, u.user == nil, u.password == nil else { return nil }
        return u
    }
    static func safeName(_ raw: String) -> String {
        let clean = raw.components(separatedBy: CharacterSet(charactersIn: "/\\:\0\n\r")).joined(separator: "_").trimmingCharacters(in: .whitespacesAndNewlines)
        return clean.isEmpty || clean == "." || clean == ".." ? "未命名下载" : String(clean.prefix(180))
    }
    @discardableResult func add(_ raw: String, name: String? = nil, source: String = "直链", requestHeaders: [String: String] = [:], relativeDirectory: String? = nil, baiduPath: String? = nil) -> Bool {
        guard let u = Self.validURL(raw) else { return false }
        if items.contains(where: { $0.url == raw && ["queued", "running", "paused", "pausing"].contains($0.state) }) { return false }
        let filename = Self.safeName(name ?? (u.lastPathComponent.isEmpty ? "未命名下载" : u.lastPathComponent))
        var t = Transfer(url: raw, name: filename)
        t.source = source; t.baiduPath = baiduPath
        // Reserve the destination at enqueue time; changing the folder only affects new tasks.
        var destination = folder
        if let relativeDirectory {
            guard !relativeDirectory.hasPrefix("/"), relativeDirectory.split(separator:"/").allSatisfy({ $0 != "." && $0 != ".." }) else { return false }
            for part in relativeDirectory.split(separator:"/") { destination.appendPathComponent(Self.safeName(String(part))) }
        }
        t.path = uniquePath(filename, directory:destination).path
        items.insert(t, at: 0); headers[t.id] = requestHeaders
        notify(); schedule(); return true
    }
    private func uniquePath(_ name: String, directory: URL) -> URL {
        let initial = directory.appendingPathComponent(name)
        let ext = initial.pathExtension
        let stem = initial.deletingPathExtension().lastPathComponent
        var candidate = initial; var n = 1
        while FileManager.default.fileExists(atPath: candidate.path) || items.contains(where: { $0.path == candidate.path }) {
            candidate = directory.appendingPathComponent("\(stem) (\(n))" + (ext.isEmpty ? "" : ".\(ext)")); n += 1
        }
        return candidate
    }
    func schedule() {
        while active.count + parallel.count + refreshing.count < limit, let i = items.firstIndex(where: { $0.state == "queued" }) {
            let id = items[i].id
            if items[i].baiduPath != nil, headers[id] == nil, onRefresh != nil { refresh(id); continue }
            if !FileManager.default.fileExists(atPath: resumeURL(id).path), let url = Self.validURL(items[i].url) {
                startParallel(id: id, index: i, url: url)
                continue
            }
            startSingle(id: id, index: i)
        }
        notify()
    }
    private func startParallel(id: String, index: Int, url: URL) {
        let transfer = ParallelTransfer(url: url, directory: storage.appendingPathComponent(id + ".chunks"), headers: requestHeaders(id), connections: connections)
        parallel[id] = transfer
        items[index].state = "running"; items[index].error = ""; items[index].speed = 0
        samples[id] = (Date(), items[index].received)
        transfer.progress = { [weak self] received, total in
            guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
            self.items[i].received = received; self.items[i].total = total
            if let (date, previous) = self.samples[id], Date().timeIntervalSince(date) >= 0.35 {
                self.items[i].speed = Double(max(0, received - previous)) / Date().timeIntervalSince(date)
                self.samples[id] = (Date(), received); self.notify(persist: false)
            }
        }
        transfer.fallback = { [weak self] in
            guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
            self.parallel.removeValue(forKey: id)
            self.items[i].received = 0
            self.startSingle(id: id, index: i)
        }
        transfer.paused = { [weak self] in
            guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
            self.items[i].state = "paused"; self.items[i].speed = 0
            self.parallel.removeValue(forKey: id); self.schedule()
        }
        transfer.completed = { [weak self] result in
            guard let self, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
            switch result {
            case .success(let location):
                self.commitFile(location, index: i, id: id)
                if self.items[i].state == "completed" { try? FileManager.default.removeItem(at: self.storage.appendingPathComponent(id + ".chunks")) }
            case .failure(let error):
                self.onDiagnostic?("transfer_http_or_range_failed", (error as NSError).code)
                self.items[i].state = "failed"; self.items[i].error = error.localizedDescription
            }
            self.items[i].speed = 0; self.parallel.removeValue(forKey: id); self.samples.removeValue(forKey: id); self.schedule()
        }
        transfer.start()
    }
    private func startSingle(id: String, index i: Int) {
            let task: URLSessionDownloadTask
            if let data = try? Data(contentsOf: resumeURL(id)) {
                task = session.downloadTask(withResumeData: data)
            } else {
                guard let u = Self.validURL(items[i].url) else { items[i].state = "failed"; items[i].error = "下载地址无效"; return }
                var request = URLRequest(url: u)
                for (k, v) in requestHeaders(id) { request.setValue(v, forHTTPHeaderField: k) }
                task = session.downloadTask(with: request)
            }
            items[i].state = "running"; items[i].error = ""; items[i].speed = 0
            active[id] = task; identities[task.taskIdentifier] = id; samples[id] = (Date(), items[i].received)
            task.resume()
        notify()
    }
    private func resumeURL(_ id: String) -> URL { storage.appendingPathComponent(id + ".resume") }
    func pause(_ id: String) {
        guard let i = items.firstIndex(where: { $0.id == id }) else { return }
        if items[i].state == "refreshing" { refreshing.removeValue(forKey:id); items[i].state = "paused"; notify(); return }
        if items[i].state == "queued" { items[i].state = "paused"; notify(); return }
        if items[i].state == "running", let transfer = parallel[id] {
            items[i].state = "pausing"; transfer.pause(); return
        }
        guard items[i].state == "running", let task = active[id] else { return }
        items[i].state = "pausing"; items[i].speed = 0; notify()
        task.cancel { [weak self] data in
            DispatchQueue.main.async {
                guard let self, let index = self.items.firstIndex(where: { $0.id == id }), self.items[index].state == "pausing" else { return }
                if let data { try? data.write(to: self.resumeURL(id), options: .atomic); try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: self.resumeURL(id).path) }
                self.items[index].state = "paused"
                self.active.removeValue(forKey: id); self.identities.removeValue(forKey: task.taskIdentifier)
                self.schedule()
            }
        }
    }
    func resume(_ id: String) {
        guard let i = items.firstIndex(where: { $0.id == id }), ["paused", "failed"].contains(items[i].state) else { return }
        refreshed.remove(id)
        if items[i].baiduPath != nil, onRefresh != nil, items[i].state == "failed" { refresh(id); return }
        items[i].state = "queued"; schedule()
    }
    func remove(_ id: String) {
        refreshing.removeValue(forKey:id); refreshed.remove(id)
        parallel.removeValue(forKey: id)?.cancel()
        try? FileManager.default.removeItem(at: storage.appendingPathComponent(id + ".chunks"))
        if let task = active.removeValue(forKey: id) { identities.removeValue(forKey: task.taskIdentifier); task.cancel() }
        items.removeAll { $0.id == id }; headers.removeValue(forKey: id); samples.removeValue(forKey: id)
        try? FileManager.default.removeItem(at: resumeURL(id)); schedule()
    }
    func pauseAll() { for id in items.filter({ ["running", "queued", "refreshing"].contains($0.state) }).map(\.id) { pause(id) } }
    func resumeAll() { for id in items.filter({ ["paused", "failed"].contains($0.state) }).map(\.id) { resume(id) } }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard let id = identities[downloadTask.taskIdentifier], let i = items.firstIndex(where: { $0.id == id }), items[i].state == "running" else { return }
        items[i].received = totalBytesWritten; items[i].total = max(0, totalBytesExpectedToWrite)
        if let (date, previous) = samples[id], Date().timeIntervalSince(date) >= 0.35 {
            items[i].speed = Double(max(0, totalBytesWritten - previous)) / Date().timeIntervalSince(date)
            samples[id] = (Date(), totalBytesWritten); notify(persist: false)
        }
    }
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        guard let id = identities[downloadTask.taskIdentifier], let i = items.firstIndex(where: { $0.id == id }) else { return }
        guard let response = downloadTask.response as? HTTPURLResponse, (200...299).contains(response.statusCode) else {
            items[i].state = "failed"; items[i].error = "服务器返回 HTTP \((downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0)"
            let status = (downloadTask.response as? HTTPURLResponse)?.statusCode ?? 0
            onDiagnostic?("download_http_rejected", status)
            if let data = try? Data(contentsOf:location), data.count < 16384,
               let object = (try? JSONSerialization.jsonObject(with:data)) as? [String:Any], let code = object["error_code"] as? Int {
                onDiagnostic?("baidu_download_rejected",code)
                items[i].error += "（百度代码 \(code)）"
            }
            items[i].received = 0; items[i].total = 0
            if status == 403 { items[i].error += "。请刷新下载授权后重试；若仍失败，请重新读取文件。" }
            return
        }
        if response.mimeType == "text/html" && !(response.value(forHTTPHeaderField: "Content-Disposition") ?? "").lowercased().contains("attachment") {
            items[i].state = "failed"; items[i].error = "这个地址返回网页。请在网盘中选择文件下载，或使用文件直链。"; return
        }
        // PCS can return a provider error as HTTP 200. An error document is
        // never a successfully downloaded cloud file.
        if items[i].source == "百度网盘", response.mimeType == "application/json",
           !(response.value(forHTTPHeaderField:"Content-Disposition") ?? "").lowercased().contains("attachment"),
           let size = (try? FileManager.default.attributesOfItem(atPath:location.path)[.size]) as? NSNumber, size.intValue < 16384,
           let data = try? Data(contentsOf:location), let object = (try? JSONSerialization.jsonObject(with:data)) as? [String:Any],
           let code = (object["error_code"] ?? object["errno"]) as? Int, code != 0 {
            items[i].state = "failed"; items[i].received = 0; items[i].total = 0
            items[i].error = "百度 PCS 接口拒绝下载（代码 \(code)）。未保存错误响应为文件。"
            onDiagnostic?("pcs_download_rejected",code); return
        }
        commitFile(location, index: i, id: id)
    }
    private func commitFile(_ location: URL, index i: Int, id: String) {
        do {
            var target = URL(fileURLWithPath: items[i].path)
            try FileManager.default.createDirectory(at: target.deletingLastPathComponent(), withIntermediateDirectories: true)
            // Never overwrite a file created while the transfer was running.
            if FileManager.default.fileExists(atPath: target.path) {
                target = target.deletingLastPathComponent().appendingPathComponent("\(target.deletingPathExtension().lastPathComponent)-\(id.prefix(8))" + (target.pathExtension.isEmpty ? "" : ".\(target.pathExtension)"))
            }
            try FileManager.default.moveItem(at: location, to: target)
            items[i].path = target.path; items[i].name = target.lastPathComponent
            items[i].received = (try FileManager.default.attributesOfItem(atPath: target.path)[.size] as? NSNumber)?.int64Value ?? items[i].received
            items[i].total = items[i].received; items[i].state = "completed"; items[i].error = ""
            try? FileManager.default.removeItem(at: resumeURL(id))
        } catch { items[i].state = "failed"; items[i].error = error.localizedDescription }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let id = identities[task.taskIdentifier], let i = items.firstIndex(where: { $0.id == id }) else { return }
        if items[i].state == "pausing" { return }
        if let error {
            items[i].state = "failed"; items[i].error = error.localizedDescription
            if let data = (error as NSError).userInfo[NSURLSessionDownloadTaskResumeData] as? Data {
                try? data.write(to: resumeURL(id), options: .atomic)
                try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: resumeURL(id).path)
            } else { try? FileManager.default.removeItem(at: resumeURL(id)) }
        }
        items[i].speed = 0; active.removeValue(forKey: id); identities.removeValue(forKey: task.taskIdentifier); samples.removeValue(forKey: id)
        if (task.response as? HTTPURLResponse)?.statusCode == 403, items[i].baiduPath != nil, !refreshed.contains(id), onRefresh != nil {
            refresh(id); return
        }
        schedule()
    }
    private func requestHeaders(_ id: String) -> [String:String] {
        var h = headers[id] ?? [:]
        if let t = items.first(where: { $0.id == id }), t.source == "百度网盘", let host = URL(string:t.url)?.host,
           host == "pcs.baidu.com" || host.hasSuffix(".pcs.baidu.com") {
            h["User-Agent"] = "pan.baidu.com"
            h["Referer"] = "https://pan.baidu.com/"
        }
        return h
    }
    private func refresh(_ id: String) {
        guard let i = items.firstIndex(where: { $0.id == id }), let path = items[i].baiduPath, let onRefresh else { return }
        let ticket = UUID(); refreshing[id] = ticket; refreshed.insert(id)
        items[i].state = "refreshing"; items[i].speed = 0; items[i].error = ""; notify()
        onDiagnostic?("download_link_refresh", 0)
        onRefresh(path) { [weak self] result in
            guard let self, self.refreshing[id] == ticket, let i = self.items.firstIndex(where: { $0.id == id }) else { return }
            self.refreshing.removeValue(forKey:id)
            switch result {
            case .success(let (raw,h)):
                guard Self.validURL(raw) != nil else { self.items[i].state = "failed"; self.items[i].error = "刷新返回无效下载地址"; self.schedule(); return }
                if self.items[i].url != raw {
                    try? FileManager.default.removeItem(at:self.resumeURL(id))
                    try? FileManager.default.removeItem(at:self.storage.appendingPathComponent(id + ".chunks"))
                    self.items[i].received = 0; self.items[i].total = 0
                }
                self.items[i].url = raw; self.headers[id] = h; self.items[i].state = "queued"
            case .failure(let error):
                self.items[i].state = "failed"; self.items[i].error = error.localizedDescription
                self.onDiagnostic?("download_link_refresh_failed", (error as NSError).code)
            }
            self.schedule()
        }
    }
    func urlSession(_ session: URLSession, task: URLSessionTask, willPerformHTTPRedirection response: HTTPURLResponse, newRequest request: URLRequest, completionHandler: @escaping (URLRequest?) -> Void) {
        var next = request
        if let agent = task.originalRequest?.value(forHTTPHeaderField:"User-Agent") { next.setValue(agent,forHTTPHeaderField:"User-Agent") }
        if response.url?.host?.lowercased() != request.url?.host?.lowercased() {
            next.setValue(nil, forHTTPHeaderField: "Cookie")
            next.setValue(nil, forHTTPHeaderField: "Authorization")
        }
        if response.url?.scheme == "https", request.url?.scheme != "https" {
            completionHandler(nil); return
        }
        completionHandler(next)
    }

}
