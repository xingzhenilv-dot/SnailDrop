import Cocoa
import ApplicationServices
import CryptoKit

final class BaiduClient {
    struct Item { let name: String; let detail: String }
    struct Node { var role = ""; var text = ""; var selected = false; var directory: String? = nil; var children: [Node] = [] }
    struct Snapshot { let items: [Item]; let pid: pid_t; let fingerprint: String; let directory: String? }
    private var deadline = Date.distantFuture
    private var preview: Snapshot?
    let bundleID = "com.baidu.netdisk"
    var onScan: ((Int, Int) -> Void)?
    var onStats: ((String, Int) -> Void)?
    private var maxDepth = 0
    private var truncated = 0
    var running: NSRunningApplication? { NSRunningApplication.runningApplications(withBundleIdentifier: bundleID).first { !$0.isTerminated } }
    var status: [String: Any] {
        let path = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleID)
        return ["installed":path != nil, "running":running != nil, "accessible":AXIsProcessTrusted(), "version":path.flatMap { Bundle(url:$0)?.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String } ?? "未知"]
    }
    func launch() {
        guard let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleID) else { return }
        NSWorkspace.shared.openApplication(at: url, configuration: NSWorkspace.OpenConfiguration(), completionHandler: nil)
    }
    func requestAccess() {
        let options = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true] as CFDictionary
        _ = AXIsProcessTrustedWithOptions(options)
    }
    private func attribute(_ element: AXUIElement, _ key: String) -> CFTypeRef? {
        var value: CFTypeRef?; guard AXUIElementCopyAttributeValue(element, key as CFString, &value) == .success else { return nil }; return value
    }
    private func text(_ element: AXUIElement) -> String {
        for key in [kAXTitleAttribute, kAXValueAttribute, kAXDescriptionAttribute] {
            if let raw = attribute(element,key) {
                let value = (raw as? String) ?? (raw as? NSAttributedString)?.string ?? ""
                if !value.isEmpty, value.count < 500 { return value }
            }
        }
        return ""
    }
    private func tree(_ element: AXUIElement, depth: Int, budget: inout Int) -> Node {
        guard budget > 0, depth < 64, Date() < deadline else { truncated += 1; return Node() }; budget -= 1
        maxDepth = max(maxDepth,depth)
        let role = attribute(element, kAXRoleAttribute) as? String ?? ""
        let selected = (attribute(element, kAXSelectedAttribute) as? NSNumber)?.boolValue ?? false
        let children = attribute(element, kAXChildrenAttribute) as? [AXUIElement] ?? []
        let ignored = [kAXTextFieldRole,kAXTextAreaRole,kAXImageRole,kAXButtonRole,"AXLink"]
        let leaf = ignored.contains(role) ? "" : text(element)
        var directory: String?
        if let raw = attribute(element,"AXURL") {
            let url = (raw as? URL) ?? (raw as? String).flatMap(URL.init(string:))
            if let url { directory = Self.directory(from:url) }
        }
        return Node(role: role, text: leaf, selected: selected, directory:directory, children: children.prefix(500).map { tree($0, depth: depth + 1, budget: &budget) })
    }
    static func texts(_ n: Node) -> [String] { (n.text.isEmpty ? [] : [n.text]) + n.children.flatMap(texts) }
    static func rows(_ n: Node) -> [(Node, Item)] {
        // Chromium inserts layout-only AXGroups between rows and cell text.
        // Prefer the smallest subtree containing a name, size/type, and date.
        let nested = n.children.flatMap(rows)
        if !nested.isEmpty { return nested }
        var seen = Set<String>()
        let strings = texts(n).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty && seen.insert($0).inserted }
        guard strings.count >= 3, strings.count <= 24 else { return [] }
        let datePattern = #"^\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}"#
        let sizePattern = #"^\d+(\.\d+)?\s*(B|K|M|G|T|KB|MB|GB|TB|KiB|MiB|GiB)$"#
        let dates = strings.filter { $0.range(of: datePattern, options: .regularExpression) != nil }
        guard dates.count == 1, let date = dates.first,
              !strings.contains("\u{6587}\u{4ef6}\u{540d}") else { return [] }
        let size = strings.first { $0 == "\u{6587}\u{4ef6}\u{5939}" || $0.range(of:sizePattern,options:[.regularExpression,.caseInsensitive]) != nil }
        guard let size else { return [] }
        guard let name = strings.first(where: { $0 != "-" && $0 != date && $0 != size && $0 != "\u{6587}\u{4ef6}\u{5939}" && $0.range(of:sizePattern,options:[.regularExpression,.caseInsensitive]) == nil }) else { return [] }
        return [(n, Item(name:name,detail:size + " · " + date))]
    }
    static func selection(_ roots: [Node]) -> [Item] {
        let all = roots.flatMap(rows)
        func hasSelected(_ n: Node) -> Bool { n.selected || n.children.contains(where: hasSelected) }
        let marked = all.filter { hasSelected($0.0) }
        if !marked.isEmpty { return marked.map(\.1) }
        // Electron may omit AXSelected on custom rows. This fallback is exact:
        // one visible row and an explicit first-party '1 selected' status.
        let values = roots.flatMap(texts)
        if all.count == 1 && values.contains(where: { $0.range(of: #"已选中\s*1\s*个文件"#, options: .regularExpression) != nil }) { return [all[0].1] }
        return []
    }
    func readSelection() throws -> Snapshot {
        guard let app = running else { throw error(1,"请先打开百度网盘客户端。") }
        guard AXIsProcessTrusted() else { throw error(2,"需要在系统设置 → 隐私与安全性 → 辅助功能中允许蜗牛速递读取客户端界面。授权后点击重新读取。") }
        deadline = Date().addingTimeInterval(12); maxDepth = 0; truncated = 0
        let root = AXUIElementCreateApplication(app.processIdentifier)
        AXUIElementSetMessagingTimeout(root, 2)
        // Electron exposes its renderer tree after a trusted assistive client
        // enables manual accessibility. This does not grant system permission.
        AXUIElementSetAttributeValue(root, "AXManualAccessibility" as CFString, kCFBooleanTrue)
        AXUIElementSetAttributeValue(root, "AXEnhancedUserInterface" as CFString, kCFBooleanTrue)
        Thread.sleep(forTimeInterval: 0.15)
        let windows = attribute(root,kAXWindowsAttribute) as? [AXUIElement] ?? []
        var budget = 5000
        let trees = windows.prefix(10).map { tree($0,depth:0,budget:&budget) }
        onScan?(5000 - budget, trees.flatMap(Self.rows).count)
        onStats?("client_scan_depth",maxDepth)
        onStats?("client_scan_truncated",truncated)
        onStats?("client_scan_text_nodes",trees.flatMap(Self.texts).count)
        onStats?("client_scan_date_nodes",trees.flatMap(Self.texts).filter { $0.range(of:#"\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}"#,options:.regularExpression) != nil }.count)
        let items = Self.selection(trees)
        guard !items.isEmpty else { throw error(3,"无法准确识别客户端所选文件。请打开文件主窗口并选中一项；若客户端不暴露选中状态，可用搜索只显示这一项后重试。也可复制已有分享链接导入。") }
        let fingerprint = SHA256.hash(data: Data(items.map { $0.name+"\n"+$0.detail }.joined(separator:"\n").utf8)).map { String(format:"%02x",$0) }.joined()
        let snapshot = Snapshot(items:items,pid:app.processIdentifier,fingerprint:fingerprint,directory:trees.first(where: { !Self.selection([$0]).isEmpty }).flatMap { Self.directories($0).first }); preview = snapshot; return snapshot
    }
    static func directory(from url: URL) -> String? {
        guard url.isFileURL, url.path.contains("/BaiduNetdisk.app/Contents/Resources/"), let fragment = url.fragment, !fragment.contains("downloading"), !fragment.contains("uploading") else { return nil }
        if let path = URLComponents(string:fragment)?.queryItems?.first(where: { $0.name == "path" })?.value, path.hasPrefix("/"), !path.split(separator:"/").contains("..") { return path }
        return fragment == "/" || fragment.hasPrefix("/?category=all") ? "/" : nil
    }
    private static func directories(_ n: Node) -> [String] { (n.directory.map { [$0] } ?? []) + n.children.flatMap(directories) }
    private func error(_ code: Int, _ message: String) -> NSError { NSError(domain:"SnailDrop.Client",code:code,userInfo:[NSLocalizedDescriptionKey:message]) }
}
