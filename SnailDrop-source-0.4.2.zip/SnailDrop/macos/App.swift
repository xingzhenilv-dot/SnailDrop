import Cocoa
import WebKit

final class CloudBrowser: NSObject, WKNavigationDelegate, WKUIDelegate, NSWindowDelegate {
    var window: NSWindow!
    var web: WKWebView!
    var onDownload: ((String, String?, [String: String], String?, String?) -> Void)?
    var onNotice: ((String) -> Void)?
    var onDiagnostic: ((String, Int) -> Void)?
    var onShare: (([String: Any]) -> Void)?
    private let agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Safari/605.1.15"
    private var generation = 0
    private var pending: URL?
    private var timer: Timer?
    private var busy = false
    private var authenticated = false
    private var phase = "idle"
    private var started = Date()
    private var catalog: [String: [String: Any]] = [:]
    private var currentFiles: [[String: Any]] = []
    private var currentDirectory = ""
    private var title = "百度分享"
    private var personalPaths: [String] = []
    private var personal = false
    private var waitingRefresh: [(String, (Result<(String,[String:String]),Error>) -> Void)] = []
    override init() {
        super.init()
        let config = WKWebViewConfiguration(); config.websiteDataStore = .default()
        web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = self; web.uiDelegate = self; web.customUserAgent = agent
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1050, height: 760), styleMask: [.titled, .closable, .resizable], backing: .buffered, defer: false)
        window.title = "登录百度网盘 · 完成后自动返回蜗牛速递"
        window.contentView = web; window.delegate = self; window.isReleasedWhenClosed = false; window.center()
    }
    func emit(_ status: String, _ message: String = "") {
        onShare?(["personal":personal, "status": status, "message": message, "session": generation, "files": currentFiles, "directory": currentDirectory, "title": title])
    }
    func open(_ url: URL) {
        cancel(emitState: false)
        guard url.scheme == "https", ["pan.baidu.com", "yun.baidu.com"].contains(url.host ?? ""), url.path.hasPrefix("/s/") || url.path.hasPrefix("/share/") else {
            emit("error", "请输入百度分享链接。当前流程不处理个人网盘主页。"); return
        }
        personal = false; personalPaths = []
        pending = url; authenticated = false; phase = "checking"; started = Date()
        catalog = [:]; currentFiles = []; currentDirectory = ""; title = "百度分享"
        emit("loading", "正在检查登录状态并读取分享…")
        web.load(URLRequest(url: url))
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in self?.poll() }
    }
    func openPersonal(_ paths: [String]) {
        cancel(emitState:false); personal = true; personalPaths = paths
        pending = URL(string:"https://pan.baidu.com/disk/main")!; authenticated = false; phase = "checking"; started = Date()
        catalog = [:]; currentFiles = []; currentDirectory = ""; title = "客户端所选 · 蜗牛下载"
        emit("loading","正在检查蜗牛的百度下载授权…")
        web.load(URLRequest(url:pending!))
        timer = Timer.scheduledTimer(withTimeInterval:2,repeats:true) { [weak self] _ in self?.poll() }
    }
    func cancel(emitState: Bool = true) {
        generation += 1; timer?.invalidate(); timer = nil; web?.stopLoading(); window?.orderOut(nil)
        busy = false; phase = "idle"; pending = nil
        if emitState {
            let waiting = waitingRefresh; waitingRefresh.removeAll()
            for (_,done) in waiting { done(.failure(NSError(domain:"SnailDrop",code:NSUserCancelledError,userInfo:[NSLocalizedDescriptionKey:"已取消下载授权刷新。"]))) }
            emit("cancelled", "已取消解析，未开始下载。")
        }
    }
    func windowWillClose(_ notification: Notification) { if phase != "idle" && phase != "ready" { cancel() } }
    func run(_ filename: String, arguments: [String: Any], completion: @escaping ([String: Any]) -> Void) {
        let ticket = generation
        guard let file = Bundle.main.resourceURL?.appendingPathComponent("frontend/" + filename), let script = try? String(contentsOf: file, encoding: .utf8) else { completion(["status":"error", "message":"应用资源缺失，请重新构建。"]); return }
        web.callAsyncJavaScript(script, arguments: arguments, in: nil, in: .page) { [weak self] result in
            guard let self, self.generation == ticket else { return }
            switch result {
            case .success(let value): completion(value as? [String: Any] ?? ["status":"error", "message":"百度返回数据格式异常。"])
            case .failure(let error): self.onDiagnostic?("provider_script_failed", (error as NSError).code); completion(["status":"loading"])
            }
        }
    }
    func poll() {
        guard pending != nil, ["checking","login","verification"].contains(phase) else { return }
        if phase == "checking" && Date().timeIntervalSince(started) > 60 { fail("分享加载超时，请检查网络后重新解析。"); return }
        guard !busy else { return }
        busy = true
        if !authenticated {
            run("baidu-share.js", arguments: ["operation":"auth", "directory":""]) { [weak self] data in
                guard let self else { return }; self.busy = false
                if data["status"] as? String == "authenticated" {
                    self.authenticated = true; self.phase = "checking"; self.started = Date()
                    self.window.orderOut(nil); self.emit("loading", "登录成功，正在读取分享文件…")
                    if let u = self.pending, self.web.url?.path != u.path {
                        self.web.load(URLRequest(url: u))
                    }
                } else if data["status"] as? String == "login" {
                    if self.phase != "login" {
                        self.phase = "login"; self.window.title = "登录百度网盘 · 完成后自动返回蜗牛速递"
                        self.window.makeKeyAndOrderFront(nil); self.emit("login", "请在百度官方窗口登录，成功后会自动返回。")
                        let login = URL(string: "https://pan.baidu.com/disk/main")!
                        self.web.load(URLRequest(url: login))
                    }
                }
            }
        } else {
            run(personal ? "baidu-personal.js" : "baidu-share.js", arguments: ["operation":"inspect", "directory":"", "paths":personalPaths]) { [weak self] data in
                guard let self else { return }; self.busy = false
                switch data["status"] as? String {
                case "ready": self.accept(data, directory: "")
                case "verification":
                    self.phase = "verification"; self.window.title = "百度分享验证 · 完成后自动返回蜗牛速递"; self.window.makeKeyAndOrderFront(nil)
                    self.emit("verification", data["message"] as? String ?? "请完成分享验证。")
                case "error": self.fail(data["message"] as? String ?? "分享不可访问。")
                default: break
                }
            }
        }
    }
    private func accept(_ data: [String: Any], directory: String) {
        currentFiles = data["files"] as? [[String: Any]] ?? []
        for f in currentFiles { if let id = f["id"] as? String { catalog[id] = f } }
        currentDirectory = directory; title = data["title"] as? String ?? title
        busy = false; phase = "ready"; timer?.invalidate(); timer = nil; window.orderOut(nil); emit("ready")
        let waiting = waitingRefresh; waitingRefresh.removeAll()
        for (path,done) in waiting { refreshPersonal(path,completion:done) }
    }
    private func fail(_ message: String) {
        busy = false; phase = "error"; timer?.invalidate(); timer = nil; window.orderOut(nil); emit("error", message)
        let waiting = waitingRefresh; waitingRefresh.removeAll()
        for (_,done) in waiting { done(.failure(NSError(domain:"SnailDrop",code:401,userInfo:[NSLocalizedDescriptionKey:message]))) }
    }
    func browse(_ id: String, session: Int) {
        guard session == generation, phase == "ready", !busy else { return }
        let dir: String
        if id.isEmpty { dir = "" }
        else { guard let f = catalog[id], f["directory"] as? Bool == true, let path = f["path"] as? String, !path.isEmpty else { return }; dir = path }
        busy = true; emit("loading", "正在读取文件夹…")
        run(personal ? "baidu-personal.js" : "baidu-share.js", arguments: ["operation":dir.isEmpty ? "inspect" : "list", "directory":dir, "paths":personalPaths]) { [weak self] data in
            guard let self else { return }
            if data["status"] as? String == "ready" { self.accept(data, directory: dir) }
            else { self.busy = false; self.emit("ready", data["message"] as? String ?? "文件夹读取失败，请重试。") }
        }
    }
    func confirm(ids: [String], archive: Bool, session: Int) {
        guard session == generation, phase == "ready", !busy, !ids.isEmpty, ids.count <= 100 else { return }
        let unique = Array(Set(ids)); let files = unique.compactMap { catalog[$0] }
        guard files.count == unique.count else { return }
        let requested: [[String: Any]] = files.map { ["fs_id": $0["id"]!, "server_filename": $0["name"]!, "isdir": ($0["directory"] as? Bool == true ? 1 : 0), "path": $0["path"] ?? ""] }
        busy = true; phase = "resolving"; emit("resolving", "正在获取所选文件的下载地址…")
        run(personal ? "baidu-personal.js" : "baidu-provider.js", arguments: ["archive":archive, "preferPCS":personal, "requestedFiles":requested, "operation":"download", "paths":files.compactMap { $0["path"] as? String }, "directory":""]) { [weak self] data in
            guard let self else { return }; self.busy = false; self.phase = "ready"
            if data["ok"] as? Bool == true, let links = data["links"] as? [[String:String]], !links.isEmpty {
                for link in links { if let raw = link["url"], let url = URL(string: raw) { self.capture(url, name:link["name"], relativeDirectory:link["relativeDirectory"], baiduPath:link["baiduPath"]) } }
                self.emit("ready", "已提交所选下载，可在下方队列查看进度。")
            } else { self.onDiagnostic?("download_link_failed", data["code"] as? Int ?? 0); self.emit("ready", data["message"] as? String ?? "获取下载地址失败，请重试或重新解析分享。") }
        }
    }
    func refreshPersonal(_ path: String, completion: @escaping (Result<(String,[String:String]),Error>) -> Void) {
        guard authenticated, let host = web.url?.host, ["pan.baidu.com","yun.baidu.com"].contains(host) else {
            waitingRefresh.append((path,completion))
            if waitingRefresh.count == 1 { openPersonal([path]) }
            return
        }
        run("baidu-personal.js", arguments:["operation":"download","paths":[path],"directory":"","preferPCS":true]) { [weak self] data in
            guard let self else { return }
            guard data["ok"] as? Bool == true, let links = data["links"] as? [[String:String]], links.count == 1,
                  links[0]["baiduPath"] == path, let raw = links[0]["url"], let url = DownloadEngine.validURL(raw) else {
                completion(.failure(NSError(domain:"SnailDrop",code:data["code"] as? Int ?? 1,userInfo:[NSLocalizedDescriptionKey:data["message"] as? String ?? "下载授权刷新失败，请重新读取文件。"])))
                return
            }
            self.web.configuration.websiteDataStore.httpCookieStore.getAllCookies { cookies in
                let filtered = Self.cookies(cookies, for:url)
                var h = HTTPCookie.requestHeaderFields(with:filtered)
                h["User-Agent"] = self.agent; h["Referer"] = "https://pan.baidu.com/"
                completion(.success((raw,h)))
            }
        }
    }
    private static func cookies(_ cookies: [HTTPCookie], for url: URL) -> [HTTPCookie] {
        let host = url.host?.lowercased() ?? ""
        return cookies.filter { c in
            let domain = c.domain.hasPrefix(".") ? String(c.domain.dropFirst()).lowercased() : c.domain.lowercased()
            return (host == domain || (c.domain.hasPrefix(".") && host.hasSuffix("." + domain))) && (!c.isSecure || url.scheme == "https") && url.path.hasPrefix(c.path) && (c.expiresDate == nil || c.expiresDate! > Date())
        }
    }
    func capture(_ url: URL, name: String?, relativeDirectory: String? = nil, baiduPath: String? = nil) {
        guard ["http", "https"].contains(url.scheme ?? "") else { onNotice?("暂不支持此网页的 blob 下载，请使用文件直链。"); return }
        let ticket = generation
        let referer = web.url?.absoluteString ?? "https://pan.baidu.com/"
        web.configuration.websiteDataStore.httpCookieStore.getAllCookies { [weak self] cookies in
            guard let self, self.generation == ticket else { return }
            let filtered = Self.cookies(cookies, for:url)
            var h = HTTPCookie.requestHeaderFields(with: filtered)
            h["User-Agent"] = self.agent; h["Referer"] = referer
            self.onDownload?(url.absoluteString, name, h, relativeDirectory, baiduPath)
            self.onNotice?("已将确认的文件加入下载队列。")
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { poll() }
    func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        // The authentication window must never enqueue downloads. Only confirm() may do so.
        guard !action.shouldPerformDownload, let url = action.request.url, ["https","http","about"].contains(url.scheme ?? "") else { decisionHandler(.cancel); return }
        decisionHandler(.allow)
    }
    func webView(_ webView: WKWebView, decidePolicyFor response: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
        let attachment = ((response.response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition") ?? "").lowercased().contains("attachment")
        decisionHandler(attachment || !response.canShowMIMEType ? .cancel : .allow)
    }
    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for action: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        if let u = action.request.url, ["http","https"].contains(u.scheme ?? "") { webView.load(action.request) }; return nil
    }
    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        if (error as NSError).code != NSURLErrorCancelled { fail("百度页面加载失败，请检查网络后重新解析。") }
    }
    func logout() {
        cancel(); let store = web.configuration.websiteDataStore
        store.removeData(ofTypes: WKWebsiteDataStore.allWebsiteDataTypes(), modifiedSince: .distantPast) { [weak self] in self?.onNotice?("已清除蜗牛速递内的百度登录信息。") }
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, NSWindowDelegate {
    var window: NSWindow!
    var web: WKWebView!
    var engine: DownloadEngine!
    var browser: CloudBrowser!
    var timer: Timer?
    var clientTimer: Timer?
    let client = BaiduClient()
    let clientWorker = DispatchQueue(label: "SnailDrop.Client")
    var clientState: [String: Any] = ["status":"idle", "items":[], "message":"先在百度客户端选中文件，再读取。"]
    var logger: SessionLog!
    var lastStates: [String:String] = [:]
    var lastClientRunning = false
    var terminating = false
    var clientSnapshot: BaiduClient.Snapshot?
    func applicationDidFinishLaunching(_ notification: Notification) {
        let support = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("CloudHarbor")
        logger = SessionLog(directory: support.appendingPathComponent("session-logs"))
        client.onStats = { [weak self] event, count in DispatchQueue.main.async { self?.logger.record(event,count:count) } }
        client.onScan = { [weak self] nodes, rows in
            DispatchQueue.main.async { self?.logger.record("client_scan_nodes", count:nodes); self?.logger.record("client_scan_rows", count:rows) }
        }
        logger.onChange = { [weak self] in self?.pushDiagnostics() }
        let path = UserDefaults.standard.string(forKey: "downloadFolder")
        let folder = path.map { URL(fileURLWithPath: $0) } ?? FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0].appendingPathComponent("CloudHarbor")
        engine = DownloadEngine(storage: support, folder: folder)
        engine.limit = max(1, min(5, UserDefaults.standard.integer(forKey: "concurrency") == 0 ? 3 : UserDefaults.standard.integer(forKey: "concurrency")))
        engine.onChange = { [weak self] in
            guard let self else { return }
            for t in self.engine.items where self.lastStates[t.id] != t.state {
                self.lastStates[t.id] = t.state
                self.logger.record("transfer_" + t.state, count: self.engine.items.count, error:t.state == "failed")
            }
            self.pushState()
        }
        engine.connections = [1,4,8].contains(UserDefaults.standard.integer(forKey:"connections")) ? UserDefaults.standard.integer(forKey:"connections") : 4
        engine.onDiagnostic = { [weak self] event,code in self?.logger.record(event,code:code,error:code != 0) }
        browser = CloudBrowser()
        engine.onRefresh = { [weak self] path,completion in
            guard let self else { return }
            guard self.client.running != nil else { completion(.failure(NSError(domain:"SnailDrop",code:1,userInfo:[NSLocalizedDescriptionKey:"请先打开百度客户端。"] ))); return }
            self.browser.refreshPersonal(path,completion:completion)
        }
        browser.onDownload = { [weak self] url, name, headers, directory, baiduPath in
            guard let self else { return }
            guard self.client.running != nil else { self.logger.record("client_not_running",error:true); self.toast("百度客户端已退出，请重新打开后确认下载。"); return }
            if !self.engine.add(url, name: name, source:"百度网盘",requestHeaders:headers,relativeDirectory:directory,baiduPath:baiduPath) { self.toast("该下载已存在，或链接无效。") }
            self.window.makeKeyAndOrderFront(nil)
        }
        browser.onDiagnostic = { [weak self] event, code in self?.logger.record(event,code:code,error:true) }
        browser.onNotice = { [weak self] message in self?.toast(message) }
        browser.onShare = { [weak self] data in
            guard let self, let encoded = try? JSONSerialization.data(withJSONObject: data), let json = String(data: encoded, encoding: .utf8) else { return }
            let status = data["status"] as? String ?? "unknown"
            self.logger.record("share_" + status, count:(data["files"] as? [Any])?.count ?? 0, error:status == "error")
            self.web?.evaluateJavaScript("window.receiveShareState && window.receiveShareState(\(json))", completionHandler: nil)
            if data["status"] as? String == "ready" { self.window.makeKeyAndOrderFront(nil) }
        }
        let config = WKWebViewConfiguration(); config.websiteDataStore = .nonPersistent()
        config.userContentController.add(self, name: "cloudharbor")
        web = WKWebView(frame: .zero, configuration: config); web.navigationDelegate = self; web.uiDelegate = self
        web.setValue(false, forKey: "drawsBackground")
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1180, height: 780), styleMask: [.titled, .closable, .miniaturizable, .resizable, .fullSizeContentView], backing: .buffered, defer: false)
        window.title = "蜗牛速递 SnailDrop"; window.titleVisibility = .hidden; window.titlebarAppearsTransparent = true
        window.backgroundColor = NSColor(calibratedRed: 0.965, green: 0.976, blue: 0.98, alpha: 1)
        window.minSize = NSSize(width: 920, height: 640); window.contentView = web; window.delegate = self
        window.setFrameAutosaveName("CloudHarborMainWindow"); window.center(); window.makeKeyAndOrderFront(nil)
        let page = Bundle.main.resourceURL!.appendingPathComponent("frontend/index.html")
        web.loadFileURL(page, allowingReadAccessTo: page.deletingLastPathComponent())
        lastClientRunning = client.running != nil
        clientTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in self?.updateClient() }
        makeMenu(); NSApp.activate(ignoringOtherApps: true)
        timer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in self?.engine.save() }
    }
    func updateClient() {
        let running = client.running != nil
        if running != lastClientRunning {
            logger.record(running ? "client_started" : "client_stopped")
            if !running { for t in engine.items where t.source == "百度网盘" { engine.pause(t.id) } }
            lastClientRunning = running
        }
        pushClient()
    }
    func pushClient() {
        guard web != nil else { return }
        var data = clientState; data["client"] = client.status
        if let encoded = try? JSONSerialization.data(withJSONObject:data), let json = String(data:encoded,encoding:.utf8) {
            web.evaluateJavaScript("window.receiveClientState && window.receiveClientState(\(json))",completionHandler:nil)
        }
    }
    func pushDiagnostics() {
        guard web != nil, logger != nil else { return }
        web.evaluateJavaScript("window.receiveDiagnostics && window.receiveDiagnostics(\(jsString(logger.report())))",completionHandler:nil)
    }
    func readClient() {
        clientState = ["status":"reading", "items":[], "message":"正在读取百度客户端的选中文件…"]; pushClient()
        logger.record("client_read_requested")
        clientWorker.async { [weak self] in
            guard let self else { return }
            do {
                let snapshot = try self.client.readSelection()
                DispatchQueue.main.async {
                    self.clientSnapshot = snapshot
                    self.clientState = ["status":"ready", "items":snapshot.items.map { ["name":$0.name,"detail":$0.detail] }, "message":"已读取文件信息。接下来在蜗牛中获取下载地址，选择文件后加入本应用队列。"]
                    self.logger.record("client_selection_ready", count:snapshot.items.count); self.pushClient()
                }
            } catch {
                let code = (error as NSError).code; let message = error.localizedDescription
                DispatchQueue.main.async {
                    self.clientState = ["status":"error", "items":[], "message":message]
                    self.logger.record("client_selection_failed",code:code,error:true); self.pushClient()
                }
            }
        }
    }
    func confirmClient() {
        guard client.running != nil, let snapshot = clientSnapshot, clientState["status"] as? String == "ready" else { return }
        guard let directory = snapshot.directory else { clientState["message"] = "未能读取客户端当前目录，请返回文件列表后重新读取。"; pushClient(); return }
        let paths = snapshot.items.map { directory.hasSuffix("/") ? directory + $0.name : directory + "/" + $0.name }
        guard snapshot.items.allSatisfy({ !$0.name.contains("/") && $0.name != "." && $0.name != ".." }) else { return }
        logger.record("client_resolve_in_snail",count:paths.count)
        browser.openPersonal(paths)
        clientState["message"] = "正在为蜗牛自己的下载引擎获取文件信息；需要时请完成百度授权。"; pushClient()
    }
    func windowWillClose(_ notification: Notification) {
        if notification.object as? NSWindow === window { NSApp.terminate(nil) }
    }
    func makeMenu() {
        let menu = NSMenu(); let root = NSMenuItem(); let appMenu = NSMenu()
        appMenu.addItem(withTitle: "关于蜗牛速递", action: #selector(about), keyEquivalent: "")
        appMenu.addItem(.separator()); appMenu.addItem(withTitle: "退出蜗牛速递", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        root.submenu = appMenu; menu.addItem(root)
        let edit = NSMenuItem(); edit.title = "编辑"; let em = NSMenu(title: "编辑")
        for (title, selector, key) in [("撤销", "undo:", "z"), ("剪切", "cut:", "x"), ("复制", "copy:", "c"), ("粘贴", "paste:", "v"), ("全选", "selectAll:", "a")] { em.addItem(withTitle: title, action: Selector(selector), keyEquivalent: key) }
        edit.submenu = em; menu.addItem(edit)
        let win = NSMenuItem(); let wm = NSMenu(title: "窗口"); win.title = "窗口"; win.submenu = wm
        wm.addItem(withTitle: "显示蜗牛速递", action: #selector(showWindow), keyEquivalent: "0"); menu.addItem(win)
        NSApp.mainMenu = menu
    }
    @objc func about() { let a = NSAlert(); a.messageText = "蜗牛速递 SnailDrop"; a.informativeText = "0.4.0 · macOS 开发预览版\nmake updating greating\n独立实现的下载管理器。"; a.runModal() }
    @objc func showWindow() { window.makeKeyAndOrderFront(nil) }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { pushState(); pushClient(); pushDiagnostics() }
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(navigationAction.request.url?.isFileURL == true ? .allow : .cancel)
    }
    func webView(_ webView: WKWebView, runJavaScriptConfirmPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping (Bool) -> Void) {
        let alert = NSAlert(); alert.messageText = message; alert.addButton(withTitle: "确认"); alert.addButton(withTitle: "取消")
        alert.beginSheetModal(for: window) { response in completionHandler(response == .alertFirstButtonReturn) }
    }
    func pushState() {
        guard web != nil, let data = try? JSONEncoder().encode(engine.items), let json = String(data: data, encoding: .utf8) else { return }
        let folder = jsString(engine.folder.path)
        web.evaluateJavaScript("window.receiveNativeState && window.receiveNativeState({tasks:\(json),folder:\(folder),concurrency:\(engine.limit),connections:\(engine.connections),native:true})", completionHandler: nil)
    }
    func jsString(_ s: String) -> String { String(data: try! JSONEncoder().encode(s), encoding: .utf8)! }
    func toast(_ text: String) { web?.evaluateJavaScript("window.showToast && window.showToast(\(jsString(text)))", completionHandler: nil) }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.frameInfo.isMainFrame, message.frameInfo.request.url?.isFileURL == true,
              let body = message.body as? [String: Any], let action = body["action"] as? String else { return }
        let id = body["id"] as? String ?? ""
        switch action {
        case "ready": pushState(); pushClient(); pushDiagnostics()
        case "add":
            let urls = body["urls"] as? [String] ?? []; var count = 0
            for url in urls.prefix(100) { if engine.add(url) { count += 1 } }
            toast("已添加 \(count) 个下载任务" + (count < urls.count ? "，重复或无效地址已跳过。" : "。"))
        case "pause": engine.pause(id)
        case "connections":
            let value = body["value"] as? Int ?? 4
            engine.connections = [1,4,8].contains(value) ? value : 4
            UserDefaults.standard.set(engine.connections,forKey:"connections"); pushState()
        case "resume":
            if engine.items.first(where: { $0.id == id })?.source == "百度网盘", client.running == nil { toast("请先打开百度客户端。"); return }; engine.resume(id)
        case "remove": engine.remove(id)
        case "pauseAll": engine.pauseAll()
        case "resumeAll":
            guard client.running != nil else { toast("请先打开百度客户端。"); return }; engine.resumeAll()
        case "clearCompleted": for id in engine.items.filter({ $0.state == "completed" }).map(\.id) { engine.remove(id) }
        case "reveal":
            if let t = engine.items.first(where: { $0.id == id && $0.state == "completed" }) { NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath: t.path)]) }
        case "folder":
            try? FileManager.default.createDirectory(at: engine.folder, withIntermediateDirectories: true)
            NSWorkspace.shared.open(engine.folder)
        case "chooseFolder":
            let panel = NSOpenPanel(); panel.canChooseDirectories = true; panel.canChooseFiles = false; panel.canCreateDirectories = true; panel.allowsMultipleSelection = false
            panel.beginSheetModal(for: window) { [weak self] response in
                if response == .OK, let u = panel.url { self?.engine.folder = u; UserDefaults.standard.set(u.path, forKey: "downloadFolder"); self?.pushState() }
            }
        case "concurrency":
            engine.limit = max(1, min(5, body["value"] as? Int ?? 3)); UserDefaults.standard.set(engine.limit, forKey: "concurrency"); engine.schedule()
        case "clientLaunch": client.launch(); logger.record("client_launch_requested")
        case "clientRefresh": updateClient()
        case "clientAccess": client.requestAccess(); logger.record("client_access_requested"); updateClient()
        case "clientRead": readClient()
        case "clientConfirm": confirmClient()
        case "reportCopy":
            NSPasteboard.general.clearContents(); NSPasteboard.general.setString(logger.report(),forType:.string); toast("已复制脱敏的本次诊断报告。")
        case "reportRefresh": pushDiagnostics()
        case "baidu":
            guard client.running != nil else { logger.record("client_not_running",error:true); toast("请先打开百度网盘客户端。"); return }
            let raw = body["url"] as? String ?? "https://pan.baidu.com/disk/main"
            if let u = DownloadEngine.validURL(raw), ["pan.baidu.com", "yun.baidu.com"].contains(u.host?.lowercased() ?? "") { browser.open(u) }
        case "shareCancel": browser.cancel()
        case "shareBrowse": browser.browse(body["fileId"] as? String ?? "", session: body["session"] as? Int ?? -1)
        case "shareConfirm":
            guard client.running != nil else { toast("请先打开百度客户端再确认下载。"); logger.record("client_not_running",error:true); return }
            browser.confirm(ids: body["ids"] as? [String] ?? [], archive: body["archive"] as? Bool ?? false, session: body["session"] as? Int ?? -1)
        case "logout": browser.logout()
        case "paste":
            let s = NSPasteboard.general.string(forType: .string) ?? ""
            web.evaluateJavaScript("window.pasteLinks(\(jsString(s)))", completionHandler: nil)
        default: break
        }
    }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool { window.makeKeyAndOrderFront(nil); return true }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }
    func applicationWillTerminate(_ notification: Notification) { logger?.cleanup() }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        if terminating { return .terminateLater }
        terminating = true; clientTimer?.invalidate(); browser.cancel(emitState:false)
        logger.record("session_closing"); engine.pauseAll(); engine.save()
        // Allow URLSession to flush resume data before exiting.
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in self?.engine.save(); self?.logger.cleanup(); sender.reply(toApplicationShouldTerminate: true) }
        return .terminateLater
    }
}
