import Foundation

/// Only predefined event identifiers and numeric diagnostics are accepted. Never
/// pass URLs, cookies, account identifiers, filenames or raw server responses.
final class SessionLog {
    struct Entry: Codable { let time: String; let level: String; let event: String; let code: Int; let count: Int }
    private(set) var entries: [Entry] = []
    private(set) var diskError = false
    private var closed = false
    let directory: URL
    var onChange: (() -> Void)?
    init(directory: URL) {
        self.directory = directory
        do {
            if FileManager.default.fileExists(atPath: directory.path) { try FileManager.default.removeItem(at: directory) }
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: [.posixPermissions: 0o700])
        } catch { diskError = true }
        record("session_started")
    }
    func record(_ event: String, code: Int = 0, count: Int = 0, error: Bool = false) {
        guard !closed else { return }
        // Event identifiers are machine codes, never free-form descriptions.
        let safe = String(event.filter { $0.isASCII && ($0.isLetter || $0 == "_") }.prefix(72))
        entries.append(Entry(time: ISO8601DateFormatter().string(from: Date()), level: error ? "error" : "info", event: safe, code: code, count: count))
        if entries.count > 1000 { entries.removeFirst(entries.count - 1000) }
        do {
            let file = directory.appendingPathComponent("session.json")
            try JSONEncoder().encode(entries).write(to: file, options: .atomic)
            try FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: file.path)
        } catch { diskError = true }
        onChange?()
    }
    func report() -> String {
        var lines = ["蜗牛速递 SnailDrop · 0.4.2", "make updating greating", "仅本次运行；退出自动清理；不含文件名、分享地址或账号凭据。", "日志写入状态：" + (diskError ? "异常（以下为内存记录）" : "正常")]
        lines += entries.map { "\($0.time) [\($0.level)] \($0.event) code=\($0.code) count=\($0.count)" }
        return lines.joined(separator: "\n")
    }
    @discardableResult func cleanup() -> Bool {
        closed = true; entries.removeAll()
        do { if FileManager.default.fileExists(atPath: directory.path) { try FileManager.default.removeItem(at: directory) }; return true }
        catch { diskError = true; return false }
    }
}
