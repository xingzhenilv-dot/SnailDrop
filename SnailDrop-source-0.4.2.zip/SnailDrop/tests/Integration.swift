import Foundation
import CryptoKit

@main struct Integration {
    static func wait(_ seconds: Double = 30, until condition: () -> Bool) {
        let deadline = Date().addingTimeInterval(seconds)
        while !condition() && Date() < deadline { _ = RunLoop.main.run(mode: .default, before: Date().addingTimeInterval(0.02)) }
        precondition(condition(), "Test timed out")
    }
    static func main() throws {
        precondition(ParallelTransfer.parseRange("0-0/13108134")?.2 == 13108134)
        precondition(ParallelTransfer.parseRange("bytes 0-0/13108134")?.2 == 13108134)
        precondition(ParallelTransfer.parseRange("0-1/1") == nil)
        precondition(ParallelTransfer.parseRange("items 0-0/10") == nil)
        precondition(ParallelTransfer.httpValidator("abcdef0123456789abcdef0123456789") == "\"abcdef0123456789abcdef0123456789\"")
        let base = CommandLine.arguments[1]
        let root = URL(fileURLWithPath: CommandLine.arguments[2])
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let payload = Data((0..<(8 * 1024 * 1024)).map { UInt8($0 % 256) })
        let hash = SHA256.hash(data: payload)
        func checkFile(_ url: URL) throws { let data = try Data(contentsOf: url); precondition(SHA256.hash(data: data) == hash, "File contents differ") }
        func transfer(_ path: String, folder: String, connections: Int = 4) throws -> Double {
            var done = false; var output: URL?; var failure: Error?
            let t = ParallelTransfer(url: URL(string: base + path)!, directory: root.appendingPathComponent(folder), headers: [:], connections: connections)
            t.completed = { result in switch result { case .success(let url): output=url; case .failure(let e): failure=e }; done=true }
            t.fallback = { preconditionFailure("Unexpected fallback") }
            let start=Date(); t.start(); wait { done }
            if let failure { throw failure }; try checkFile(output!)
            return Date().timeIntervalSince(start)
        }
        let single = try transfer("/slow", folder: "one", connections: 1)
        let multi = try transfer("/slow", folder: "four")
        let eight = try transfer("/slow", folder: "eight", connections:8)
        precondition(eight < single * 0.75)
        precondition(multi < single * 0.75, "Parallel connections did not improve fixture throughput")
        print(String(format: "PASS: 8 MiB integrity + 4 connections: %.2fs vs %.2fs (%.2fx)", multi, single, single/multi))
        _ = try transfer("/retry", folder: "retry")
        print("PASS: interrupted connections retry without corrupting content")
        var paused = false; var bytes: Int64=0
        let dir = root.appendingPathComponent("pause")
        let first = ParallelTransfer(url: URL(string: base + "/slow")!, directory: dir, headers: [:])
        first.progress = { received, _ in bytes=received }
        first.paused = { paused=true }
        first.start(); wait { bytes > 512 * 1024 }; first.pause(); wait { paused }
        precondition(bytes < payload.count)
        var resumedAt: Int64 = -1; var resumeDone = false; var resumeURL: URL?
        let resumed = ParallelTransfer(url: URL(string: base + "/slow")!, directory: dir, headers: [:])
        resumed.progress = { received,_ in if resumedAt == -1 { resumedAt=received } }
        resumed.completed = { result in if case .success(let u)=result { resumeURL=u }; resumeDone=true }
        resumed.start(); wait { resumeDone }; precondition(resumedAt > 0); try checkFile(resumeURL!)
        print("PASS: new transfer instance resumes persisted segments")
        var rejected=false
        let bad = ParallelTransfer(url: URL(string: base + "/bad-range")!, directory: root.appendingPathComponent("bad"), headers: [:])
        bad.completed = { result in if case .failure = result { rejected=true } }
        bad.start(); wait { rejected }
        print("PASS: incorrect Content-Range rejected")
        let engine = DownloadEngine(storage: root.appendingPathComponent("engine"), folder: root.appendingPathComponent("downloads"))
        engine.limit=2
        precondition(!engine.add("file:///etc/passwd"))
        precondition(engine.add(base + "/single", name:"test.bin"))
        precondition(!engine.add(base + "/single", name:"test.bin"))
        precondition(engine.add(base + "/slow", name:"test.bin"))
        precondition(engine.add(base + "/baidu-zip", name:"baidu.zip"))
        precondition(engine.add(base + "/html"))
        precondition(engine.add(base + "/missing"))
        wait { engine.items.allSatisfy { ["completed","failed"].contains($0.state) } }
        precondition(engine.items.filter { $0.state == "completed" }.count == 3)
        precondition(engine.items.filter { $0.state == "failed" }.count == 2)
        for t in engine.items where t.state == "completed" { try checkFile(URL(fileURLWithPath:t.path)) }
        precondition(Set(engine.items.map(\.path)).count == 5)
        let restored=DownloadEngine(storage: root.appendingPathComponent("engine"), folder: root.appendingPathComponent("downloads"))
        precondition(restored.items.count == 5)
        print("PASS: fallback, queue, duplicate rejection, collision protection, HTML/404 rejection, persistence")
        precondition(engine.add(base + "/probe-only", name:"probe-only.bin"))
        wait { engine.items.first?.state == "completed" }
        try checkFile(URL(fileURLWithPath:engine.items.first!.path))
        print("PASS: origin accepting probe but ignoring real ranges restarts a full download safely")
        precondition(engine.add(base + "/range-forbidden", name:"range-forbidden.bin"))
        wait { engine.items.first?.state == "completed" }
        try checkFile(URL(fileURLWithPath:engine.items.first!.path))
        print("PASS: Range-only HTTP 403 safely retries ordinary GET")
        precondition(!engine.add(base + "/single?bad=1", relativeDirectory:"../escape"))
        precondition(engine.add(base + "/single?nested=1", name:"nested.bin", relativeDirectory:"one/two"))
        wait { engine.items.first?.state == "completed" }
        let nested = URL(fileURLWithPath:engine.items.first!.path)
        precondition(nested.path.hasSuffix("/downloads/one/two/nested.bin"))
        try checkFile(nested)
        print("PASS: relative directory preservation and traversal rejection")
        precondition(engine.add(base + "/redirect-agent",name:"redirect.bin",requestHeaders:["User-Agent":"SnailFixture"]))
        wait { engine.items.first?.state == "completed" }
        try checkFile(URL(fileURLWithPath:engine.items.first!.path))
        print("PASS: CDN host redirect preserves transfer User-Agent and Range headers")
        var refreshCount = 0; var diagnostics: [Int] = []
        engine.onDiagnostic = { _,code in diagnostics.append(code) }
        engine.onRefresh = { path,completion in
            precondition(path == "/authorized/example.bin"); refreshCount += 1
            completion(.success((base + "/renewed", ["X-Fixture-Session":"renewed"])))
        }
        precondition(engine.add(base + "/expired", name:"refresh.bin", requestHeaders:[:], baiduPath:"/authorized/example.bin"))
        wait { engine.items.first?.state == "completed" }
        precondition(refreshCount == 1 && diagnostics.contains(31045))
        try checkFile(URL(fileURLWithPath:engine.items.first!.path))
        precondition(engine.items.first!.baiduPath == "/authorized/example.bin")
        print("PASS: HTTP 403 refreshes once, restores request headers, preserves task identity, records numeric provider error")
        engine.onRefresh = { _,completion in completion(.success((base + "/expired",[:]))) }
        precondition(engine.add(base + "/expired?again",name:"forbidden.bin",baiduPath:"/authorized/example.bin"))
        wait { engine.items.first?.state == "failed" }
        precondition(engine.items.first!.received == 0 && engine.items.first!.total == 0)
        print("PASS: persistent HTTP 403 stops without an unbounded refresh loop or saving an error body as a file")
        var lateCompletion: ((Result<(String,[String:String]),Error>) -> Void)?
        engine.onRefresh = { _,completion in lateCompletion = completion }
        engine.resume(engine.items.first!.id)
        precondition(engine.items.first!.state == "refreshing")
        engine.pause(engine.items.first!.id)
        lateCompletion?(.success((base + "/renewed",["X-Fixture-Session":"renewed"])))
        precondition(engine.items.first!.state == "paused")
        print("PASS: pausing during authorization refresh ignores the late response")
        precondition(engine.add(base + "/pcs-json-error",name:"must-not-save.pdf",source:"百度网盘"))
        wait { engine.items.first?.state == "failed" }
        precondition(!FileManager.default.fileExists(atPath:engine.items.first!.path))
        precondition(diagnostics.contains(31042))
        print("PASS: HTTP 200 PCS error JSON is rejected without writing a fake downloaded file")
        print("All integration tests passed. This is a local fixture result, not a Baidu speed measurement.")
    }
}
