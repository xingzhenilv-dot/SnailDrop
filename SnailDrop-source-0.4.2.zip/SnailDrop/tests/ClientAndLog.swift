import Cocoa

@main struct ClientAndLog {
    static func main() throws {
        let root = URL(fileURLWithPath:CommandLine.arguments[1])
        try FileManager.default.createDirectory(at:root,withIntermediateDirectories:true)
        let logs = root.appendingPathComponent("session-logs")
        try FileManager.default.createDirectory(at:logs,withIntermediateDirectories:true)
        try Data("stale".utf8).write(to:logs.appendingPathComponent("old.log"))
        let logger = SessionLog(directory:logs)
        precondition(!FileManager.default.fileExists(atPath:logs.appendingPathComponent("old.log").path))
        logger.record("client_selection_failed",code:3,error:true)
        let report = logger.report()
        precondition(report.contains("client_selection_failed") && report.contains("code=3"))
        precondition(logger.cleanup())
        precondition(!FileManager.default.fileExists(atPath:logs.path))
        logger.record("late_callback")
        precondition(!FileManager.default.fileExists(atPath:logs.path))
        let next = SessionLog(directory:logs); precondition(!next.report().contains("client_selection_failed")); next.cleanup()
        print("PASS: previous-session cleanup, error report, exit cleanup, late-callback suppression")
        func row(_ name: String, selected: Bool = false) -> BaiduClient.Node {
            .init(role:"AXGroup",selected:selected,children:[.init(role:"AXGroup",children:[.init(role:"AXStaticText",text:name)]),.init(role:"AXStaticText",text:"10MB"),.init(role:"AXStaticText",text:"文件"),.init(role:"AXStaticText",text:"2026.10.27 09:30")])
        }
        let wrapped = BaiduClient.Node(children:[
            .init(children:[.init(role:"AXStaticText",text:"nested.txt")]),
            .init(children:[.init(children:[.init(role:"AXStaticText",text:"1.2M")])]),
            .init(children:[.init(role:"AXStaticText",text:"2026.10.27 09:30")])
        ])
        precondition(BaiduClient.rows(wrapped).map { $0.1.name } == ["nested.txt"])
        precondition(BaiduClient.rows(.init(children:[row("a"),row("b")])).count == 2)
        let clientURL = URL(string:"file:///Applications/BaiduNetdisk.app/Contents/Resources/core.asar/index.html#/?path=%2Fparent")!
        precondition(BaiduClient.directory(from:clientURL) == "/parent")
        precondition(BaiduClient.directory(from:URL(string:"file:///Applications/BaiduNetdisk.app/Contents/Resources/core.asar/index.html#/downloading")!) == nil)
        let status = BaiduClient.Node(role:"AXStaticText",text:"已选中1个文件/文件夹")
        let one = BaiduClient.Node(children:[status,row("example.txt")])
        precondition(BaiduClient.selection([one]).map(\.name)==["example.txt"])
        precondition(BaiduClient.selection([.init(children:[status,row("a"),row("b")])]).isEmpty)
        precondition(BaiduClient.selection([.init(children:[row("a"),row("b",selected:true)])]).map(\.name)==["b"])
        precondition(BaiduClient.selection([.init(children:[row("a")])]).isEmpty)
        print("PASS: explicit selection, exact single-row fallback, ambiguous/missing selection rejection")
    }
}
