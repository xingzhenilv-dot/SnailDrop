const assert=require('node:assert/strict');
const fs=require('node:fs');
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const script=new AsyncFunction('window','document','location','localStorage','fetch','archive',fs.readFileSync(__dirname+'/../frontend/baidu-provider.js','utf8'));
async function run({files=[{fs_id:123,server_filename:'example.bin',isdir:0}],responses=[{errno:0,list:[{fs_id:123,dlink:'https://example.test/download',server_filename:'example.bin'}]}],selected=['123'],archive=false,info={},host='pan.baidu.com'}={}){
 const calls=[];
 const window={locals:{dump:()=>({file_list:{value:files},share_uk:'1',shareid:'2',sign:'test-sign',timestamp:123,...info})}};
 const document={cookie:'BDCLND=test-key',querySelectorAll:()=>selected.map(id=>({getAttribute:k=>k==='data-file-key'?id:null,querySelector:()=>true}))};
 const location={hostname:host,protocol:'https:',pathname:'/s/1test',search:''};
 const fetch=async(url,options)=>{calls.push({url,options});return {ok:true,json:async()=>responses.shift()};};
 const result=await script(window,document,location,{getItem:()=>null},fetch,archive);
 return {result,calls};
}
(async()=>{
 let t=await run();assert.equal(t.result.ok,true);assert.equal(t.calls.length,1);assert.equal(t.calls[0].options.body.get('type'),'nolimit');
 t=await run({responses:[{errno:0,list:'encrypted'}, {errno:0,dlink:'https://example.test/archive'}]});assert.equal(t.result.ok,true);assert.equal(t.calls[1].options.body.get('type'),'batch');
 t=await run({files:[{fs_id:123,server_filename:'folder',isdir:1}],responses:[{errno:0,dlink:'https://example.test/archive'}]});assert.equal(t.calls[0].options.body.get('type'),'batch');
 t=await run({responses:[{errno:-20}]});assert.equal(t.result.ok,false);assert.match(t.result.message,/验证码/);assert.equal(t.calls.length,1);
 t=await run({files:[{fs_id:123},{fs_id:456}],selected:[]});assert.equal(t.result.ok,false);assert.equal(t.calls.length,0);
 t=await run({archive:true,responses:[{errno:0,dlink:'https://example.test/archive'}]});assert.equal(t.calls[0].options.body.get('type'),'batch');
 t=await run({host:'example.test'});assert.equal(t.result.ok,false);assert.equal(t.calls.length,0);
 t=await run({info:{sign:null,timestamp:null},responses:[{data:{sign:'fresh',timestamp:456}},{errno:0,list:[{dlink:'https://example.test/file'}]}]});assert.equal(t.result.ok,true);assert.match(t.calls[0].url,/\/share\/tplconfig\?/);
 console.log('PASS: Baidu provider selection, folder ZIP, encrypted-list fallback, captcha, host guard, nested signature response');
})().catch(e=>{console.error(e);process.exitCode=1});
