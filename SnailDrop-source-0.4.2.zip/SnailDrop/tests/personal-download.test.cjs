const assert=require('node:assert/strict'),fs=require('node:fs');
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const script=new AsyncFunction('location','fetch','operation','paths','directory','preferPCS',fs.readFileSync(__dirname+'/../frontend/baidu-personal.js','utf8'));
global.btoa=s=>Buffer.from(s,'binary').toString('base64');
const auth={errno:0,result:{sign1:'Plaintext',sign3:'Key',timestamp:123,bdstoken:'test'}};
const location={protocol:'https:',hostname:'pan.baidu.com'};
const folder={path:'/parent/folder',server_filename:'folder',isdir:1,fs_id:1};
const file={path:'/parent/folder/sub/example.bin',server_filename:'example.bin',isdir:0,size:32,fs_id:2};
async function run(operation,responses,paths=['/parent/folder'],preferPCS=false){
 const calls=[];const fetch=async(url,options)=>{calls.push(url);assert.equal(options.cache,'no-store');assert.ok(new URL('https://pan.baidu.com'+url).searchParams.has('_'));assert.ok(responses.length,'Unexpected request');return {ok:true,json:async()=>responses.shift()};};
 return {result:await script(location,fetch,operation,paths,'',preferPCS),calls};
}
(async()=>{
 let t=await run('inspect',[{errno:0,info:[folder]}]);assert.equal(t.result.status,'ready');assert.equal(t.result.files[0].id,'1');assert.ok(t.calls.every(u=>u.startsWith('/api/filemetas?')));
 t=await run('download',[{errno:0,info:[folder]},{errno:0,list:[file]},auth,{errno:0,dlink:[{fs_id:2,dlink:'https://example.test/download'}]}]);assert.equal(t.result.ok,true);assert.equal(t.result.links[0].relativeDirectory,'folder/sub');assert.equal(t.result.links[0].name,'example.bin');const q=new URL('https://pan.baidu.com'+t.calls.at(-1));assert.equal(q.searchParams.get('sign'),'u/MW6NlArwrT');
 t=await run('download',[{errno:0,info:[file]},auth,{errno:0,dlink:[]}],[file.path]);assert.equal(t.result.ok,false);assert.match(t.result.message,/下载地址/);
 t=await run('inspect',[],['/../secret']);assert.equal(t.result.status,'error');assert.equal(t.calls.length,0);
 t=await run('inspect',[{errno:-6}]);assert.equal(t.result.ok,false);assert.equal(t.result.code,-6);
 t=await run('download',[{errno:0,info:[file]},{errno:0,result:{}}],[file.path]);assert.equal(t.result.ok,false);assert.match(t.result.message,/签名/);
 const stale='https://example.test/file?dstime='+Math.floor(Date.now()/1000-7200)+'&expires=1h';
 const fresh='https://example.test/file?dstime='+Math.floor(Date.now()/1000)+'&expires=8h';
 t=await run('download',[{errno:0,info:[file]},auth,{errno:0,dlink:[{fs_id:2,dlink:stale}]},{errno:0,info:[{...file,dlink:fresh}]}],[file.path]);
 assert.equal(t.result.links[0].url,fresh);assert.equal(t.result.links[0].baiduPath,file.path);assert.ok(t.calls.at(-1).includes('dlink=1'));
 t=await run('download',[{errno:0,info:[file]},auth,{errno:0,dlink:[{fs_id:2,dlink:stale}]},{errno:0,info:[{...file,dlink:stale}]}],[file.path]);assert.equal(t.result.ok,false);assert.match(t.result.message,/已过期/);
 t=await run('download',[{errno:0,info:[file]}],[file.path],true);assert.equal(t.result.ok,true);const pcs=new URL(t.result.links[0].url);assert.equal(pcs.hostname,'pcs.baidu.com');assert.equal(pcs.searchParams.get('method'),'download');assert.equal(pcs.searchParams.get('path'),file.path);assert.equal(pcs.searchParams.has('BDUSS'),false);
 t=await run('download',[{errno:0,info:[folder]},{errno:0,list:[{...folder,path:folder.path+'/子目录',fs_id:3}]},{errno:0,list:[{...file,path:folder.path+'/子目录/中文文件.pdf'}]}],undefined,true);
 assert.equal(t.result.ok,true);assert.equal(t.result.links[0].relativeDirectory,'folder/子目录');assert.equal(t.result.links[0].name,'中文文件.pdf');assert.ok(t.calls.every(u=>!u.startsWith('/api/download')&&!u.startsWith('/api/gettemplatevariable')));
 const many=Array.from({length:80},(_,i)=>({...file,fs_id:i+10,path:'/parent/'+('中文目录'.repeat(18))+i+'/文件.pdf'}));let requests=0;
 const boundedFetch=async(raw)=>{
  requests++;assert.ok(raw.length<4000,'request must fit below the server URI limit');
  const query=new URL('https://pan.baidu.com'+raw).searchParams;
  const targets=JSON.parse(query.get('target'));
  return {ok:true,json:async()=>({errno:0,info:targets.map(p=>many.find(f=>f.path===p))})};
 };
 const bounded=await script(location,boundedFetch,'inspect',many.map(f=>f.path),'',true);
 assert.equal(bounded.status,'ready');assert.equal(bounded.files.length,80);assert.ok(requests>1);
 const httpError=await script(location,async()=>({ok:false,status:414}),'inspect',[file.path],'',true);assert.equal(httpError.code,414);
 console.log('PASS: whole-folder PCS links preserve nested paths without web signatures; long Chinese selections use bounded requests; HTTP 414 is logged numerically');
 console.log('PASS: metadata preview, recursive native-download links, relative directories, missing links, unsafe paths, auth errors, missing signing data rejection');
})().catch(e=>{console.error(e);process.exitCode=1});
