"""Deterministic range server, including broken and slow origins. Local tests only."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import time, re, socket, threading
PAYLOAD = bytes(range(256)) * 32768  # 8 MiB
lock = threading.Lock()
failures = 0
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def do_GET(self):
        global failures
        path = self.path.split('?')[0]
        if path == '/redirect-agent':
            self.send_response(302); self.send_header('Location',f'http://localhost:{self.server.server_port}/require-agent'); self.send_header('Content-Length','0'); self.end_headers(); return
        if path == '/require-agent' and self.headers.get('User-Agent') != 'SnailFixture':
            self.send_error(403); return
        if path == '/expired' or (path == '/renewed' and self.headers.get('X-Fixture-Session') != 'renewed'):
            body=b'{"error_code":31045,"error_msg":"user not exists"}'
            self.send_response(403); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        if path == '/missing':
            self.send_error(404); return
        if path == '/pcs-json-error':
            body=b'{"error_code":31042,"error_msg":"user is not login"}'
            self.send_response(200); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body); return
        if path == '/range-forbidden' and self.headers.get('Range'):
            self.send_error(403); return
        if path == '/html':
            data = b'<html>Sign in</html>'
            self.send_response(200); self.send_header('Content-Type','text/html'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data); return
        match = re.fullmatch(r'bytes=(\d+)-(\d*)', self.headers.get('Range',''))
        start, end = (int(match[1]), int(match[2] or len(PAYLOAD)-1)) if match else (0,len(PAYLOAD)-1)
        partial = bool(match) and path != '/single' and not (path == '/probe-only' and self.headers.get('If-Range'))
        if not partial: start,end=0,len(PAYLOAD)-1
        if start >= len(PAYLOAD): self.send_error(416); return
        body=PAYLOAD[start:end+1]
        self.send_response(206 if partial else 200)
        self.send_header('Content-Type','application/octet-stream')
        if path != '/baidu-zip': self.send_header('ETag','"fixture-v1"')
        else: self.send_header('Content-Encoding','none')
        self.send_header('Content-Length',str(len(body)))
        if partial:
            bad_start = start + 1 if path == '/bad-range' and end > 0 else start
            self.send_header('Content-Range',('' if path == '/baidu-zip' else 'bytes ')+f'{bad_start}-{end}/{len(PAYLOAD)}')
        self.end_headers()
        cutoff = False
        with lock:
            if path == '/retry' and len(body)>1 and failures < 2:
                failures += 1; cutoff=True
        try:
            for offset in range(0,len(body),65536):
                self.wfile.write(body[offset:offset+65536]); self.wfile.flush()
                if cutoff and offset >= 131072:
                    self.connection.shutdown(socket.SHUT_RDWR); self.connection.close(); return
                if path in ['/slow','/single']: time.sleep(0.015625)
        except (BrokenPipeError, ConnectionResetError): pass
if __name__ == '__main__':
    import sys
    server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    open(sys.argv[1],'w').write(str(server.server_port))
    server.serve_forever()
