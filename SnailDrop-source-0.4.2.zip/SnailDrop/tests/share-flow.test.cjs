const assert=require('node:assert/strict');const fs=require('node:fs');
const AsyncFunction=Object.getPrototypeOf(async function(){}).constructor;
const read=new AsyncFunction('window','document','location','fetch','operation','directory',fs.readFileSync(__dirname+'/../frontend/baidu-share.js','utf8'));
const download=new AsyncFunction('window','document','location','localStorage','fetch','archive','requestedFiles',fs.readFileSync(__dirname+'/../frontend/baidu-provider.js','utf8'));
const location={hostname:'pan.baidu.com',protocol:'https:',pathname:'/s/1example',search:''};
const document={title:'Test share',body:{innerText:''},cookie:'',querySelector:()=>null,querySelectorAll:()=>[]};
const root=[{fs_id:123,server_filename:'Folder',isdir:1,path:'/Folder',size:0}];
const window={locals:{dump:()=>({file_list:{value:root},share_uk:12,shareid:34,sign:'test',timestamp:123})}};
function mock(responses){const calls=[];return {calls,fetch:async(url,options)=>{calls.push({url,options});assert.ok(responses.length,'Unexpected network call');return {ok:true,json:async()=>responses.shift()};}};}
(async()=>{
 let m=mock([{result:{is_login:0}}]);let r=await read(window,document,location,m.fetch,'auth','');assert.equal(r.status,'login');
 m=mock([{result:{is_login:1}}]);r=await read(window,document,location,m.fetch,'auth','');assert.equal(r.status,'authenticated');
 m=mock([]);r=await read(window,document,location,m.fetch,'inspect','');assert.equal(r.status,'ready');assert.equal(r.files[0].id,'123');assert.equal(m.calls.length,0);assert.equal(r.files[0].directory,true);
 const page=Array.from({length:100},(_,i)=>({fs_id:200+i,server_filename:'file'+i,isdir:0,path:'/Folder/file'+i,size:8}));
 m=mock([{errno:0,list:page,has_more:1},{errno:0,list:[{fs_id:300,server_filename:'last',size:10,isdir:0}],has_more:0}]);
 r=await read(window,document,location,m.fetch,'list','/Folder');assert.equal(r.files.length,101);assert.ok(m.calls.every(c=>c.url.startsWith('/share/list?')));assert.match(m.calls[1].url,/page=2/);
 m=mock([{errno:-9}]);r=await read(window,document,location,m.fetch,'list','/Folder');assert.equal(r.status,'error');
 m=mock([]);r=await read({}, {...document,body:{innerText:'请输入提取码'},querySelector:()=>({})},location,m.fetch,'inspect','');assert.equal(r.status,'verification');
 m=mock([]);r=await read({}, {...document,body:{innerText:'分享已过期'}},location,m.fetch,'inspect','');assert.equal(r.status,'error');
 // Explicit app selection must supersede the hidden page's root folder.
 m=mock([{errno:0,list:[{fs_id:456,dlink:'https://example.test/file',server_filename:'chosen.txt'}]}]);
 r=await download(window,document,location,{getItem:()=>null},m.fetch,false,[{fs_id:'456',server_filename:'chosen.txt',isdir:0}]);assert.equal(r.ok,true);assert.equal(m.calls[0].options.body.get('fid_list'),'[456]');
 m=mock([]);r=await download(window,document,location,{getItem:()=>null},m.fetch,false,[]);assert.equal(r.ok,false);assert.equal(m.calls.length,0);
 console.log('PASS: login detection, read-only preview, directory pagination/errors, verification, explicit confirmation selection, empty selection rejection');
})().catch(e=>{console.error(e);process.exitCode=1});
