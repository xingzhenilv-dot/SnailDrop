# SnailDrop

Current plan: [PLAN.md](PLAN.md).

The active strategy uses the running official Baidu client for selected-file downloads. The previous webpage strategy remains a separate fallback.
