# GitHub 免自有 AppKey 路线调研

2026-10-27。只阅读公开实现核对协议，没有安装或运行第三方程序，也没有复制其实现代码。

## BaiduPCS-Go：用户会话式 PCS

参考固定版本 [下载接口](https://github.com/qjfoidnh/BaiduPCS-Go/blob/1b9131817aaf8ca7dee24bc00e33ebc4c7a5cc73/baidupcs/download.go) 和 [请求准备](https://github.com/qjfoidnh/BaiduPCS-Go/blob/1b9131817aaf8ca7dee24bc00e33ebc4c7a5cc73/baidupcs/prepare.go)。项目提供 PCS 直接文件下载和 locatedownload 定位接口，并使用用户自己的登录会话；不是必须让每个使用者申请 OAuth AppKey。

蜗牛本轮独立实现的是 PCS 直接文件下载兼容路线，尚未实现 locatedownload 的设备签名和多 CDN 节点选择。只从蜗牛自身的 WebKit 取得按域匹配的 Cookie，放在内存请求头中。向百度请求文件，不读取百度官方客户端私有凭据，不上传第三方解析站。88.9 MB 真实任务已传输并验证非零断点继续，尚未完成最终文件校验。

## LinkSwift：借用 Client ID 的 OAuth

参考固定版本 [脚本](https://github.com/hmjz100/LinkSwift/blob/8283da03e6c78576ebca8b1604161bcd54ade82e/（改）网盘直链下载助手.user.js)。其个人网盘路线通过 OAuth 获取 access_token，再请求 xpan filemetas，并在下载请求带上 access_token。授权页文本明确说明使用其他应用的 Client ID。

因此“使用者不申请 AppKey”不等于没有 OAuth 应用身份。蜗牛没有直接借用该 Client ID，也没有自动替用户给其他应用授予网盘访问权限。本轮使用前一种本机会话路线。

## 速度结论

获取有效文件流和提高吞吐量是两个问题。PCS 解决了本轮测试文件的原始 403 阻塞；连接数只在服务端允许的范围内发挥作用。短时八路有较高平均速度，但随后超时，默认四路更保守。没有不限速、账号权益提升或稳定高速的实测证据。
